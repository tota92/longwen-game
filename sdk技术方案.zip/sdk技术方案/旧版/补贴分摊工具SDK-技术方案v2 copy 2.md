# 补贴分摊工具 SDK 技术方案

> 关联文档：《补贴分摊工具1.0-产品需求文档v1.md》（PRD v1.1）
> 范围：前端 SDK（配置工具区块 + 模板选择 + 只读展示 + 校验 + 试算），**仅面向 PC Web 宿主**；不含计费引擎后端、核验看板后端、分摊模板存储管理与自动匹配算法、移动端（小程序 / 移动 H5）任何展示与渲染
> 交付形态：npm 私有仓库多包（Monorepo）

---

## 1. 方案概述

### 1.1 背景

PRD 第 3 节将产品拆为「配置工具」与「营销计费中心」两部分。本方案覆盖**配置工具的前端部分**：以 SDK 形式嵌入优惠券（含三方券）、促销活动业务域页面与**规则引擎配置页**（Vue 2 / Vue 3 / React 技术栈并存），提供「配置优惠分摊」区块的编辑态、模板选择、只读态、试算与校验能力。**全部能力仅面向 PC Web 宿主，移动端不展示、不渲染。**

选择 SDK 化而非各业务域重复开发的原因：

- PRD 9.1 要求配置工具以**页面内区块**形式嵌入多个宿主页面，多份实现必然导致校验规则、文案、计算口径漂移，违反 PRD 14.3「校验规则、文案、计算口径各端一致」；
- PRD 10 节试算口径必须与 T+1 正式计费一致，计算逻辑需要**单点维护、多处复用**（前端试算 + 服务端计费共用同一份引擎代码）；
- PRD 9.7 模板选择流程涉及跨「活动配置页」与「规则引擎配置页」两类宿主的一致交互，必须单点实现（SDK 仅提供模板下拉选择，自动匹配由宿主/后端在 SDK 外部完成）。

### 1.2 设计目标与原则

| 原则 | 说明 |
| --- | --- |
| 逻辑单点维护 | 校验规则、计算口径、文案全部收敛在框架无关的核心层，UI 只负责渲染 |
| 框架无关交付 | 一份 UI 源码，产出 Vue 3 组件、Web Component、React 封装三种产物，覆盖 Vue 2/3/React 宿主 |
| 宿主零污染 | 不注入全局样式/全局变量/全局事件，不留单例状态，可挂载可销毁；SDK 内置 httpClient 仅请求约定三接口，不触碰宿主其他网络通道 |
| 单端交付 | **仅 PC Web**：移动端（小程序 + 移动 H5）不展示、不渲染；校验规则、文案、计算口径在 core 单点维护，与后端 T+1 计费严格一致 |
| 模板职责最小化 | SDK 仅做模板下拉选择与 ID/名称记录，不做自动匹配、不填充模板内容、不回写模板；四个宿主场景行为一致 |
| 可验收 | PRD 9.4 的 8 条交互规则、9.7 模板规则、10 节算例全部转化为自动化测试用例 |

### 1.3 PRD 功能 ↔ SDK 模块映射

| PRD 条目 | 功能 | SDK 模块 |
| --- | --- | --- |
| 9.1 | 「配置优惠分摊」内嵌区块、多实例并存 | `SubsidySection` 主组件（实例隔离 Store） |
| 9.2 / 9.3 | 按比例 / 按固定金额两种分摊配置（含补贴顺位拖拽） | `RatioModeEditor` / `FixedModeEditor` + `BearerCard` |
| —（PRD 外新增） | 按券面值分摊：单门店承担方 + 券面值上限只读，无添加/试算 | `CouponFaceValueEditor` |
| 9.7 / 9.4-6 | 模板下拉选择（手动），payload 仅记录模板 ID/名称，修改不回写模板 | httpClient 调接口 1 + `TemplateSelect` 下拉 |
| 9.7 | 规则引擎内配置分摊规则（模板编辑） | `SubsidySection usage="templateRule"` 模板编辑模式 |
| 9.4-7 | 校验与「必改错误」展示（含比例>0） | `@core` 校验引擎 + `ErrorSummary` / 行内错误 |
| 9.5 | 试算（PC 浮层面板） | `TrialPanel` + `@core` 计算引擎 |
| 9.4-1 / 9.4-3 / 9.4-4 | 默认三承担方、自动补齐、删除监控 | `@core` 状态机 Actions |
| 9.4-2 | 试算前置校验 | `@core` 校验引擎（`TRIAL_PRECHECK`） |
| 9.6 / 14.1 | 详情 / 审批页只读展示（不区分来源，含移动端默认规则） | `SubsidySection mode="readonly"` |
| 14.2 | 移动端不进入配置工具；所建活动默认门店承担 100% | 不接入；`createMobileDefaultRule()` 数据工厂供后端落库与 PC 回显 |
| 14.1 | PC 横向卡片 + 拖拽排序（补贴顺位） | 平台适配层（容器查询 + Pointer 拖拽，仅 PC） |
| 9.4-8 | 保存草稿 / 提交随宿主表单统一提交 | 命令式 API：`validate()` + `getPayload()`，按钮归属宿主 |

非 SDK 职责（明确排除）：保存/提交/驳回/通过按钮与审批流（宿主）；补贴规则存储与版本生成（后端）；分摊模板的存储、列表管理与唯一性校验（规则引擎后端，SDK 仅提供配置界面）；**模板自动匹配/推荐算法（宿主或规则引擎后端在 SDK 外部完成）**；T+1 计费与核验看板（后端/大数据）；审批页「指定店铺、指定商品范围」与风险提示区块（宿主页面自有模块）；权限点控制（宿主透传 `mode`/`disabled`）；**移动端（小程序 + 移动 H5）的展示与渲染（含移动端审批页的分摊明细展示——由宿主自行处理或不展示）**。

---

## 2. 总体架构

### 2.1 分层架构

```
┌────────────────────────────────────────────────────────────────┐
│ 宿主应用层（业务域自有代码，SDK 不感知）                            │
│  优惠券/三方券(Vue3) │ 促销(Vue2) │ 规则引擎(React) │ 详情/审批页(只读) │
├────────────────────────────────────────────────────────────────┤
│ 适配层 Adapters（薄封装，只做 Props/事件/命令式 API 翻译）          │
│  @scope/subsidy-vue   — Vue 3 组件 / 插件                        │
│  @scope/subsidy-vue2  — Vue 2 包装组件（基于 elements）            │
│  @scope/subsidy-react — React 组件（基于 elements）                │
├────────────────────────────────────────────────────────────────┤
│ 渲染层 UI（@scope/subsidy-ui，单一 Vue 3 SFC 源码）               │
│  双产物构建：                                                      │
│   ① Vue 3 组件库（供 subsidy-vue）                                 │
│   ② Web Components（defineCustomElement，供 vue2/react/任意）      │
│  ├─ 编辑态组件族  ├─ 只读态组件族  ├─ PC 浮层策略（仅 PC）     │
├────────────────────────────────────────────────────────────────┤
│ 核心层 Core（@scope/subsidy-core，纯 TypeScript，零框架依赖）       │
│  ├─ 领域类型 & 常量文案                                            │
│  ├─ SectionStore（实例化状态容器 + 交互状态机）                     │
│  ├─ Validator（校验规则引擎）                                       │
│  ├─ Calculator（试算计算引擎，Node 可复用）                         │
│  ├─ createMobileDefaultRule（移动端默认规则工厂）          │
│  ├─ HttpClient（内置请求层，基于 axios 独立 instance，token+env 由宿主注入）   │
│  └─ Ports（宿主注入接口：httpClient 配置/埋点/上报）               │
└────────────────────────────────────────────────────────────────┘
```

关键决策：

1. **core 不依赖任何框架**，可在浏览器与 Node 双端运行。试算引擎发布为独立入口，服务端 T+1 计费可直接 `npm install` 复用，从机制上保证 PRD 9.5「计算口径与正式计费一致」；移动端默认规则工厂同属 core，保证 PRD 14.3「PC 配置与移动端默认规则共用同一计算口径」。
2. **UI 只写一套**（Vue 3 SFC），通过 Vue 官方 `defineCustomElement` 编译为原生 Web Component。React / Vue 2 宿主不感知 Vue 运行时的存在（运行时已内聚在 elements 产物内部）。
3. **SDK 内置 httpClient**。宿主注入 `token` + `env`，SDK 按 env 映射网关 baseURL，自行请求约定三接口（模板列表 / 已配置信息 / 部门列表）；基于 axios 独立 instance，不污染宿主全局 axios，不触碰宿主其他网络通道（见 3.8）。

### 2.2 Monorepo 包结构

```
subsidy-sdk/                       # pnpm workspace + changesets
├── packages/
│   ├── core/                      # @scope/subsidy-core
│   │   ├── src/types.ts           #   领域模型（附录 A）
│   │   ├── src/store.ts           #   实例化 Store + 交互 Actions
│   │   ├── src/validator.ts       #   校验规则引擎
│   │   ├── src/calculator.ts      #   试算引擎（isomorphic）
│   │   ├── src/default-rule.ts    #   移动端默认规则工厂
│   │   ├── src/http-client.ts     #   内置 httpClient：axios 独立 instance + env→网关 + token→Authorization
│   │   ├── src/api.ts             #   三接口请求函数 + bizType→applicationDomain 映射
│   │   ├── src/serializer.ts      #   前后端序列化/反序列化（元↔分、剥离前端状态字段、数组排序）
│   │   ├── src/ports.ts           #   宿主注入接口定义
│   │   └── src/messages.ts        #   全部文案常量（单点维护）
│   ├── ui/                        # @scope/subsidy-ui（不直接发布给宿主）
│   │   ├── src/components/        #   Vue 3 SFC 组件族（编辑态 / 只读态）
│   │   ├── src/overlay/           #   PC 浮层策略
│   │   ├── src/styles/            #   设计令牌 + CSS 变量
│   │   └── src/entries/
│   │       ├── vue.ts             #   产物①：Vue 3 组件入口
│   │       └── elements.ts        #   产物②：customElements 注册入口
│   ├── vue/                       # @scope/subsidy-vue（Vue 3 宿主）
│   ├── vue2/                      # @scope/subsidy-vue2（Vue 2 宿主，封装 elements）
│   └── react/                     # @scope/subsidy-react（React 宿主，封装 elements）
├── examples/
│   ├── host-vue3/                 # 优惠券域 Demo（Vue 3）
│   ├── host-vue2/                 # 促销域 Demo（Vue 2）
│   └── host-react/                # 规则引擎 Demo（React，模板编辑模式）
├── docs/                          # VitePress 接入文档
└── e2e/                           # Playwright 跨宿主同一套用例
```

> 包名 scope（如 `@busyming`）以企业私有 registry（Verdaccio/Nexus）实际为准，本文统一写作 `@scope`。

### 2.3 框架兼容策略决策

候选方案对比（与 v1.0 一致，结论不变）：

| 维度 | A. Vue3 SFC + `defineCustomElement` 双产物（**推荐**） | B. Headless Core + Vue/React 双 UI 实现 | C. 单框架 UI + 跨框架挂载运行时 |
| --- | --- | --- | --- |
| UI 代码 | 1 套 | 2 套（一致性靠纪律维持） | 1 套 |
| Vue 2 支持 | Custom Element + 薄封装 | 需额外写 Vue 2 版本 | 挂载独立 Vue 3 应用 |
| React 支持 | Custom Element + 薄封装 | 原生组件 | 挂载 Vue 3 应用，bundle 携带 Vue runtime |
| 样式隔离 | Shadow DOM 天然双向隔离 | 需自行实现（前缀/Modules） | 需自行实现 |
| 维护成本 | 低（单一源码） | 高（两套交互同步演进） | 中（双框架运行时共存的隐性成本） |
| 主要风险 | Shadow DOM 内浮层与第三方库限制（可规避，见 7.1） | 校验/交互两份实现漂移 | 宿主已有 Vue 版本冲突、样式污染面大 |

**结论：采用方案 A**。理由：

- 配置区块交互复杂度高（模板选择、拖拽排序、浮层、表单校验），双实现（方案 B）的漂移风险直接影响 PRD 16 节「各端一致」验收；
- 方案 A 的 Shadow DOM 同时解决「SDK 样式不被宿主污染」与「SDK 样式不污染宿主」两个方向（见第 7 章）；
- `defineCustomElement` 为 Vue 3 官方能力，SFC 的 `<style>`、provide/inject、插槽在 custom element 模式下均有明确定义的行为，工程风险可控；
- 同时保留**降级产物**（Light DOM + 类名前缀版，同一源码第二条构建管道），当某宿主环境确与 Shadow DOM 冲突时可无痛切换（见 7.2）。

### 2.4 运行环境基线

| 项 | 基线 | 说明 |
| --- | --- | --- |
| 浏览器 | Chrome ≥ 87、Edge ≥ 88、Safari ≥ 14（桌面端） | 不支持 IE11（依赖 Custom Elements / Shadow DOM v1 / `ResizeObserver`） |
| 宿主框架 | Vue ≥ 2.7、Vue ≥ 3.2、React ≥ 16.8 | 低于基线的宿主需先升级或使用 IIFE 产物 |
| 构建工具 | 宿主 webpack ≥ 4 / Vite ≥ 3 / Rollup 均可消费 | SDK 产物为 ESM（另附 IIFE 兜底） |
| 端形态 | **仅 PC Web（编辑 + 只读）** | 移动端（小程序 + 移动 H5）不展示、不渲染，SDK 不提供任何移动端产物与适配 |
| SSR | SDK 在 SSR 环境仅做空挂载，hydrate 后激活 | elements 注册带 `window` 守卫 |

### 2.5 SDK 应用场景矩阵

| 场景 | 宿主页面 | mode / usage | 平台 | 说明 |
| --- | --- | --- | --- | --- |
| ① 活动/券分摊配置 | 优惠券、三方券、促销活动配置页 | `mode="edit"` `usage="activityRule"` | PC | 完整能力：模板选择、编辑、校验、试算 |
| ② 规则引擎模板配置 | 规则引擎「分摊规则」配置页 | `mode="edit"` `usage="templateRule"` | PC | 编辑模板本身：无模板选择栏，其余配置项一致（PRD 9.7 引擎配置） |
| ③ 详情/审批只读 | 促销详情页、审批页 | `mode="readonly"` | PC | 只读展示分摊明细，不区分活动创建来源 |
| ④ 移动端（小程序 + 移动 H5） | 三个小程序、移动审批页 H5 | —（不接入） | — | 不展示、不渲染；小程序所建活动由后端按 `createMobileDefaultRule()` 口径落库默认规则，PC 侧正常回显 |

---
## 3. 核心层设计（@scope/subsidy-core）

### 3.1 领域模型

完整类型定义见附录 A，核心模型摘要（**字段名与枚举值对齐后端 `discount_apportion_config` 表及 `ApportionBearerDTO`**）：

```ts
/** 分摊方式（对齐后端 apportionMode 字段） */
type ApportionMode = 'RATIO' | 'FIXED_AMOUNT' | 'COUPON_FACE_VALUE'
// COUPON_FACE_VALUE 为前端预留，当前后端仅支持 RATIO / FIXED_AMOUNT，待后端补齐

/** 承担方类型（对齐后端 bearerType 字典码，一期固定三枚举，SDK 内置硬编码） */
type BearerType = 'PRODUCT_CENTER' | 'HQ' | 'STORE'

/** 商品补贴上限（对齐后端 subsidyCap 字段；仅承担方=PRODUCT_CENTER，PRD 9.2）；COUPON_FACE_VALUE 仅按券面值模式程序化设置，不进 CapSelect 下拉 */
type SubsidyCap = 'NO_CAP' | 'ARCHIVE_RETAIL_PRICE' | 'ARCHIVE_DELIVERY_PRICE' | 'COUPON_FACE_VALUE'
// COUPON_FACE_VALUE 为前端预留，待后端补齐

/** 承担方式（对齐后端 bearMode 字段；仅按固定金额，PRD 9.3） */
type BearMode = 'FIXED' | 'DYNAMIC'

/** SDK 使用场景 */
type UsageType = 'activityRule' | 'templateRule'

/** 业务类型（对齐后端 bizType；三方券/生意计划走 PROMOTION_CAMPAIGN） */
type BizType = 'PROMOTION_CAMPAIGN' | 'COUPON'

/** 部门快照（对齐后端 deptList 元素结构，来源人资系统组织架构） */
interface DeptItem {
  deptId: number
  deptCode: string
  deptName: string
}

interface ApportionBearer {
  id: string                       // 实例内唯一（SDK 生成 nanoid），纯前端状态不传后端
  bearerType: BearerType           // 对齐后端 bearerType
  deptList: DeptItem[]             // 对齐后端 deptList：HQ 必填多选；RATIO 模式下 PRODUCT_CENTER/STORE 为空；FIXED_AMOUNT 模式下非必填（PRD 9.2/9.3 差异）
  apportionPer: number | null      // 对齐后端 apportionPer：百分数（80 = 80%），null=未填；必须 > 0（PRD 9.2）
  apportionPerSource: 'manual' | 'auto' | null  // 自动补齐追踪（PRD 9.4-3），纯前端状态不传后端
  subsidyCap: SubsidyCap           // 对齐后端 subsidyCap：PRODUCT_CENTER 必填，默认 ARCHIVE_DELIVERY_PRICE
  bearMode: BearMode               // 对齐后端 bearMode：按固定金额时承担方式（按顺位自动推导，末位=DYNAMIC，其余=FIXED；不可手动选择）
  fixedAmount: number | null       // 对齐后端 fixedAmount：按固定金额时承担金额（内部以分存储，序列化时转元传后端）
  sortIndex: number                // 按固定金额：补贴顺位（拖拽排序），纯前端状态；序列化时按此排序输出数组，字段本身不传后端
}

interface ApportionConfig {
  templateId: number | null        // 对齐后端 Long；用户从下拉选中的模板 ID；选「自定义」时为 null
  templateName: string | null      // 与 templateId 同步写入，展示用，如「产品中心30%+门店70%」
  apportionMode: ApportionMode     // 对齐后端 apportionMode
  bearers: ApportionBearer[]
  ruleId?: string                  // 已保存规则回显时透传（版本逻辑在后端）
  version?: number
}

```

**数值精度约定**（前后端共用，写入 core 常量）：

- 金额内部以**分**（整数）计算，输入/展示层做元 ↔ 分转换，杜绝 `0.1 + 0.2` 浮点误差；序列化传后端时统一转为元（后端 `fixedAmount` 以元为单位，BigDecimal）；
- 比例以 **0.01%** 为最小单位（内部存整数，如 80.00% 存 8000），自动补齐的「100 − 其余之和」在整数域计算后精确到两位小数；序列化传后端时转为百分数（如 80.00）对齐 `apportionPer`；
- 舍入统一 `round-half-up`，与财务口径一致；试算结果各承担方金额之和与总额的最后一分钱差异由**顺位最后的承担方**兆底吸收（与大数拆分的常规财务处理一致，若产品另有口径可在 Calculator 配置）。

**前后端序列化约定**（写入 core `serializer.ts`）：

| 约定 | 说明 |
| --- | --- |
| 金额元/分转换 | `fixedAmount`：前端内部以分存储，序列化 `÷ 100` 转元传后端；反序列化 `× 100` 转分 |
| 数组顺序即顺位 | 序列化时按 `sortIndex` 升序排列输出 `bearers` 数组，`sortIndex` 字段本身不传后端（后端靠数组下标表示补贴顺位） |
| 前端状态字段剥离 | `id`、`apportionPerSource`、`sortIndex` 仅在 SDK 内部使用，`getPayload()` 序列化时剥离不传后端 |
| 反序列化补齐 | 后端返回数据无 `id`/`sortIndex`，SDK 反序列化时自动补 `id=nanoid()`、`sortIndex=数组下标`、`apportionPerSource=null` |

### 3.2 状态管理：实例化 SectionStore

PRD 9.1 要求「同一页面可同时存在多个配置区块实例」，因此**严禁模块级单例**。core 提供一个约 1KB 的零依赖可观察 Store 工厂：

```ts
interface Store<S> {
  getState(): Readonly<S>
  setState(patch: Partial<S> | ((s: S) => Partial<S>)): void
  subscribe(listener: (s: S, prev: S) => void): () => void
}

/** 每个区块实例调用一次，产出完全隔离的状态容器与 Actions */
function createSectionStore(options: SectionOptions): SectionStore
```

`SectionState` 结构：

```ts
interface SectionState {
  mode: 'edit' | 'readonly'
  usage: UsageType                 // activityRule=活动/券规则；templateRule=规则引擎模板
  config: ApportionConfig          // 对齐后端 ApportionConfigDTO
  templates: {                     // 模板下拉数据（httpClient 调接口 1 异步加载）
    options: ApportionTemplateVO[]
    loading: boolean
    loadFailed: boolean
  }
  configuredInfo: {                // 已配置信息（httpClient 调接口 2 拉取）
    data: ApportionConfig | null
    loading: boolean
    loadFailed: boolean
  }
  errors: ValidationError[]        // 当前校验结果（校验引擎输出）
  overlay: 'none' | 'addBearer' | 'trial'   // 当前打开的浮层（单例互斥）
  trial: { inputAmount: number | null; result: TrialResult | null; calculating: boolean }
  ui: { draggingBearerId: string | null }
}
```

Vue 3 侧通过 `shallowRef + subscribe` 绑定为响应式；Web Component 侧同样消费该 store（因为 UI 源码相同）；**React 不直接消费 store**——React 拿到的是 elements 封装后的 DOM 事件与属性，store 完全封装在元素内部，这是方案 A 的隔离红利。

状态变更全部通过命名 Actions 收敛（可单测、可加埋点切面）：

| Action | 对应 PRD 规则 | 行为要点 |
| --- | --- | --- |
| `initDefaultBearers()` | 9.4-1 | 默认生成 PRODUCT_CENTER/HQ/STORE 三行，apportionPer=null（显示“请输入”）；PRODUCT_CENTER subsidyCap 默认 `ARCHIVE_DELIVERY_PRICE` |
| `loadTemplateList()` | 9.7 | 挂载时用 httpClient 调接口 1（POST，入参：`{applicationDomain, promotionType?, activityPurposeId}`）拉取模板下拉选项；请求失败 → 下拉错误态可重试；`usage="templateRule"` 时不执行 |
| `loadConfiguredInfo()` | 9.4-8 | 挂载时用 httpClient 调接口 2（POST，入参：`{bizType, bizId}`）拉取已配置信息；成功 → 反序列化写入 config；失败 → 回退默认三承担方 + onError；`value` prop 非空时优先使用 value（覆盖/兆底） |
| `selectTemplate(id)` | 9.7 / 9.4-6 | 用户从下拉选择模板：仅将 `templateId/templateName` 写入 config，**不填充任何承担方内容**；选「自定义」（id=null）时两字段置 null |
| `setApportionMode(mode)` | 9.2/9.3 | 切换分摊方式；RATIO↔FIXED_AMOUNT 切换不清空已填承担方，仅重置模式专属字段并立即重校验；**切入 `COUPON_FACE_VALUE`** → 重置 bearers 为单行门店（bearerType=STORE、subsidyCap=COUPON_FACE_VALUE、无 apportionPer/fixedAmount/bearMode）；**切出 `COUPON_FACE_VALUE`**（回 RATIO/FIXED_AMOUNT）→ 重新 `initDefaultBearers()` 默认三承担方（单门店配置不跨模式携带） |
| `setBearerApportionPer(id, v)` | 9.4-3 | 标记 `apportionPerSource='manual'`；随后执行 `autoFillLastApportionPer()`；合计 ≠100 时产出 `RATIO_SUM_100` 错误；`v<=0` 产出 `RATIO_POSITIVE` 错误 |
| `autoFillLastApportionPer()` | 9.4-3/9.4-4 | 见 3.4 节状态机 |
| `addBearer(bearerType)` | 9.4-1 | 从 Picker 添加（已存在类型置灰不可重复，同一类型区块内唯一）；添加后执行 `deriveBearModes()`：新行成为末位→DYNAMIC，原末位→FIXED（fixedAmount 清空需重新填写） |
| `removeBearer(id)` | 9.4-4 | 剩 1 个时阻止并 toast「至少需要有一个承担方」；否则删除并触发 `autoFillLastApportionPer()` 与重排序；删除后执行 `deriveBearModes()`：新末位自动→DYNAMIC（fixedAmount 清空） |
| `deriveBearModes()` | 9.4-5 | 按 sortIndex 升序，末位行 bearMode=DYNAMIC（fixedAmount 置 null），其余行 bearMode=FIXED；原 DYNAMIC 行变为 FIXED 时 fixedAmount=null（需重新填写）；在 add/remove/reorder 后自动执行 |
| `reorderBearers(from, to)` | 9.3 / 14.1 | 更新 `sortIndex` 序列（补贴顺位）；排序后执行 `deriveBearModes()`：新末位→DYNAMIC（fixedAmount 清空），原末位→FIXED（fixedAmount=null，需重新填写） |
| `submitValidate()` | 9.4-5/9.4-7 | 运行全量校验，供宿主提交前调用 |
| `trial(amount)` | 9.5 | 前置校验 → Calculator 试算 → 写入 `state.trial.result` |

### 3.3 校验引擎

规则即数据，声明式注册，保证 PC/H5 只读数据源头、提交、试算多处调用同一份规则（**加粗行为 v2 变更**）：

| 规则码 | 级别 | 文案（messages.ts 单点维护） | 触发时机 | 适用 |
| --- | --- | --- | --- | --- |
| `RATIO_REQUIRED` | error | 请输入 | 字段 blur / 提交 | 按比例-比例为空 |
| **`RATIO_POSITIVE`** | **error** | **承担比例需大于0** | **字段 blur / 提交** | **按比例-比例 ≤ 0（PRD 9.2「各比例大于 0」）** |
| `RATIO_SUM_100` | error | 承担比例需为100%，当前{sum}% | 任一 ratio 变化即时 / 提交 | 按比例（sum 保留两位小数） |
| `DEPT_REQUIRED` | **error** | **请设置** | **字段变化 / 提交** | **承担方=HQ 且 deptList 为空（两种模式均必填）；FIXED_AMOUNT 模式下 PRODUCT_CENTER/STORE 非必填、不校验（PRD 9.3）** |
| `CAP_REQUIRED` | error | 请设置 | 字段变化 / 提交 | 承担方=PRODUCT_CENTER 且 subsidyCap 未选 |
| `AMOUNT_REQUIRED` | error | 请输入 | 字段 blur / 提交 | 固定金额为空（bearMode=FIXED 的行） |
| ~~`DYNAMIC_REQUIRED`~~ | ~~error~~ | ~~缺少动态补贴~~ | ~~shareType 变化即时 / 提交阻止~~ | 顺位自动推导保证末位始终是 dynamic，该校验永不触发 |
| `BEARER_MIN` | error(toast) | 至少需要有一个承担方 | 删除动作时 | 剩 1 行再删 |
| `TRIAL_PRECHECK` | error | 请先完善承担方信息，再进行试算。 | 点击试算 | 任一承担方必填项缺失 |

> `TEMPLATE_LOCKED` 规则码已移除：模板仅为下拉选择（记录 ID/名称），配置区始终可编辑，无需任何模板相关校验规则。
>
> `DYNAMIC_REQUIRED` 规则码：承担方式改为按顺位自动推导（末位=动态补贴），该规则永不触发，无需保留。
>
> `COUPON_FACE_VALUE` 模式**无必填可编辑字段**（承担方固定 STORE、上限固定 COUPON_FACE_VALUE、无 apportionPer/fixedAmount/部门输入），校验恒通过；`RATIO_*`/`AMOUNT_REQUIRED`/`CAP_REQUIRED`/`DEPT_REQUIRED` 均不适用；`TRIAL_PRECHECK` 不适用（无试算按钮）。

错误模型：

```ts
interface ValidationError {
  code: ErrorCode
  message: string                  // 已插值的最终文案
  level: 'error' | 'warning'       // error=必改错误（红字+标记）；warning=轻触提示
  target?: { bearerId: string; field: 'apportionPer' | 'deptList' | 'subsidyCap' | 'fixedAmount' }  // 移除 'bearMode'（承担方式不可手动编辑，无校验 targeting）
}
```

- **行内错误**：带 `target` 的错误渲染在对应卡片/行字段下方（红字）；
- **汇总错误**：`ErrorSummary` 展示「必改错误 n」，点击定位到首个错误行（scrollIntoView）；
- **提交语义**：`validate()` 仅在 `errors.filter(e => e.level==='error').length === 0` 时通过；承担方式由顺位自动推导保障（`deriveBearModes()`）。

### 3.4 关键交互状态机：自动补齐（PRD 9.4-3/9.4-4）

`autoFillLastApportionPer()` 在每次 apportionPer 变化、删除承担方后执行（与 v1.0 一致，逻辑不变）：

```
filledManual = bearers 中 apportionPerSource='manual' 且 apportionPer≠null 的行
emptyRows    = bearers 中 apportionPer=null 的行（含 auto 行被清空后）
autoRows     = bearers 中 apportionPerSource='auto' 的行

IF emptyRows.length === 1 且 filledManual 覆盖其余所有行:
    目标行.apportionPer       = round2(100 − Σ filledManual.apportionPer)   // 整数域计算
    目标行.apportionPerSource = 'auto'
ELSE IF autoRows 存在 且 用户未编辑它:
    若仍满足「唯一未填」条件 → 重算并更新 auto 值
    若不再满足（出现第二个空行）→ 清空 auto 行（apportionPer=null, apportionPerSource=null）
用户手动编辑 auto 行 → apportionPerSource 立即转为 'manual'，此后不再自动补齐
任一变化后 → 若所有行已填且 Σ≠100 → 立即产出 RATIO_SUM_100 错误
            → 任一已填行 apportionPer ≤ 0 → 产出 RATIO_POSITIVE 错误
```

该状态机用纯函数实现并配套完整单测（等价类：3 行默认、删到 2 行、删到 1 行、auto→manual 转换、合计 99.99/100.01 边界、**0 与负数比例边界**）。

### 3.5 模板选择（下拉，手动）（PRD 9.7 / 9.4-6）

SDK **不做自动模板匹配**；模板列表由 SDK 内置 httpClient 调接口 1 获取。模板能力收敛为「httpClient 拉取列表 → 下拉手动选择 → payload 记录 ID/名称」三步：

```
usage="templateRule"（规则引擎模板编辑）→ 不渲染模板下拉（编辑的就是模板本身）

usage="activityRule" 进入区块:
  挂载 → loadTemplateList()
    ├─ httpClient POST 接口 1（入参：{applicationDomain: BIZ_TYPE_TO_DOMAIN[bizType], promotionType?, activityPurposeId}）
    ├─ 请求失败 → 下拉错误态「加载失败，点击重试」（8.4），不阻塞其余配置
    └─ 成功 → 下拉选项 =「自定义」+ 模板列表（{ templateId, templateName }）

  用户选择模板:
    selectTemplate(id) → config.templateId / templateName 写入
    （不填充承担方内容、不锁定配置区、不产生预览态）
  用户选择「自定义」:
    selectTemplate(null) → templateId / templateName 置 null

  提交:
    payload 仅含 templateId / templateName（+ 用户手动配置的 bearers）
    SDK 无模板内容读取与回写通道 → 机制上保证 PRD「修改后的内容不会存到模板」
```

关键约束：

- **模板与配置内容解耦**：后端接口 1 返回完整模板内容（`ApportionTemplateVO` 含 `apportionMode + bearers`），但 SDK 当前仅消费 `templateId + templateName` 作为下拉选项，选择模板不影响承担方编辑区；若产品后续要求“选模板即套用内容”，属于新需求，可由宿主在 `value` 中传入完整配置实现（SDK 零改动）；
- **自动匹配外移**：PRD 9.7 的引擎推荐逻辑（活动类型 × 活动目的 × 启用）由宿主/后端在 SDK 外部执行；宿主希望默认选中推荐模板时，调用引擎接口后以 `value.templateId/templateName` 初始值传入即可；
- **applicationDomain 映射**：接口 1 入参 `applicationDomain` 由 SDK 从 `bizType` 自动映射（`PROMOTION_CAMPAIGN→'PROMOTION'` / `COUPON→'COUPON'`），宿主无需额外传入；
- **回显**：`value` 含 templateId/templateName 时，下拉选中对应项；若该 ID 不在当前 templateList 中（模板已停用/删除），下拉显示「自定义」但保留原 templateName 展示，避免静默丢失来源信息；
- 埋点：`template_list_loaded` / `template_selected`（payload 含 templateId）/ `template_cleared`。

### 3.6 计算引擎（试算，PRD 9.5 / 10）

纯函数、零副作用、浏览器与 Node 同构（与 v1.0 一致）。**试算为纯前端计算**：仅依赖当前配置（bearers）与用户输入的优惠金额，不请求任何后端接口：

```ts
/** 移除 TrialContext（无档案价数据来源）；新增展示字段，UI 无需 join 配置；字段名对齐后端 */
interface TrialResultItem {
  bearerId: string; bearerType: BearerType; deptList: DeptItem[]
  amount: number                   // 承担金额（分）
  apportionPer?: number            // 承担比例（%），仅 apportionMode=RATIO；展示用
  subsidyCap?: SubsidyCap          // 补贴上限枚举，仅 RATIO 且 bearerType=PRODUCT_CENTER；展示枚举标签
  bearMode?: BearMode              // 承担方式，仅 apportionMode=FIXED_AMOUNT；展示「固定金额/动态补贴」
  reason?: 'orderExhausted' | 'dynamicZero'  // 未补贴原因
  sortIndex: number
}
function calculate(input: {
  apportionMode: ApportionMode
  bearers: ApportionBearer[]
  discountAmount: number           // 假设本单优惠金额（分）
}): { items: TrialResultItem[]; total: number }
```

算法（与 PRD 10.1 对齐）：

- **按比例**：`amount_i = discount × apportionPer_i`；不再做上限命中判断（无档案价数据），`subsidyCap` 字段仅作为配置项写入 payload 并在试算面板展示枚举标签，上限执行由后端 T+1 计费保障；
- **按固定金额**：按 `sortIndex` 升序扣减，`amount_i = min(fixedAmount_i, remaining)`，`remaining` 递减至 0 后后续承担方为 0（PRD「按顺序优先扣减，直至为 0」）；DYNAMIC 行 `amount = max(0, discount − Σ fixed)`；
- Calculator 在产出 items 时从 `bearers` 拷贝展示字段（`apportionPer` / `subsidyCap` / `bearMode`），UI 直接渲染无需 join；
- 输出附带各承担方未补贴原因字段（`reason?: 'orderExhausted' | 'dynamicZero'`），为 PRD 17.1（试算展示字段待确认）预留。

**试算面板展示规则（前端计算、分模式差异化）**：`COUPON_FACE_VALUE` 模式**不提供试算**（TrialTrigger 隐藏），Calculator 仅处理 RATIO/FIXED_AMOUNT 两种模式。

输入区：「假设本单优惠金额」（元，数字输入）+「计算」按钮；点击计算 → `trial(amount)` → 前置校验（`TRIAL_PRECHECK`）→ Calculator → 渲染结果列表。

| 模式 | 结果行字段 | 来源 | 说明 |
| --- | --- | --- | --- |
| 按比例 | 承担方 | `bearerType`→label | 如「产品中心」「门店」 |
| | 承担金额 | `amount` | 高亮橙色，¥ 两位小数（如 ¥80.00） |
| | 承担比例 | `apportionPer` | 如「80.00%」 |
| | 补贴上限 | `subsidyCap` | **枚举标签**（不封顶/档案零售价/档案配送价）；**仅 bearerType=PRODUCT_CENTER 展示**，STORE/HQ 不展示该行 |
| 按固定金额 | 承担方 | `bearerType`→label | |
| | 承担金额 | `amount` | 高亮橙色 |
| | 承担方式 | `bearMode` | 「固定金额」/「动态补贴」 |
| | 动态补贴公式 | 计算 | 仅 `bearMode=DYNAMIC` 行展示：「优惠金额 − 前面承担方金额之和」（如 100 − 80 = 20） |

> 补贴上限展示的是**枚举标签**而非具体价格数值（与配置区 CapSelect 一致）；前端不做上限命中计算（TrialContext/hitCap 已移除），实际上限执行由后端 T+1 计费保障。

> 口径备注：PRD 10.1 按比例行描述「若设置了补贴上限，则补贴金额=补贴上限」，但 SDK 无档案价数据来源，无法在前端试算中执行上限判断。补贴上限（SubsidyCap）仍作为配置项保留并写入 payload，实际上限执行由后端 T+1 计费引擎保障（后端拥有价格快照数据）。若后续产品要求前端试算也展示上限命中，需新增第 4 个接口获取档案价，届时恢复 TrialContext 与 hitCap 逻辑即可。
>
> 复用：`@scope/subsidy-core/calculator` 单独发布子路径导出，服务端 T+1 计费引擎（Node）依赖同一版本，版本号锁定即锁定口径。

### 3.7 移动端默认规则工厂（PRD 14.2 / 14.3）

移动端三个小程序不进入配置工具，所建促销活动的补贴规则**默认门店承担 100%（写死）**。该默认口径由 core 单点产出，供后端落库与 **PC** 详情/审批页回显复用，杜绝各端各自硬编码。**它是纯数据工厂，与渲染端无关——移动端渲染能力移除后依然保留**：

```ts
/** 移动端创建活动的默认补贴规则（按比例、门店 100%） */
function createMobileDefaultRule(): ApportionConfig
// = { templateId: null, templateName: null,
//     apportionMode: 'RATIO',
//     bearers: [{ bearerType: 'STORE', apportionPer: 100, subsidyCap: 'NO_CAP', deptList: [], ... }] }
```

- **使用方**：① 后端在活动创建接口中为移动端来源活动落库该规则（推荐，详情/审批页即可统一回显）；② 无法落库时，PC 详情/审批宿主可在 `value` 缺失且活动来源为移动端时传入该工厂产物兆底渲染；
- **计算口径保障**：默认规则与 PC 配置同属 `ApportionConfig`，T+1 计费走同一 Calculator，满足 PRD 14.3「PC 配置与移动端默认规则共用同一计算口径」；
- **二期演进**（PRD 17.7「二期是否需要支持可配置」）：届时移动端/宿主直接以编辑态配置替换工厂产物即可，SDK 零改动。

### 3.8 宿主适配端口（Ports）

SDK 内置轻量 httpClient（基于 axios 封装），宿主仅需注入 `token` + `env`，SDK 自行请求约定三接口：

```ts
/** 环境标识 → 网关 baseURL 映射（SDK 内置，不可配置） */
type SdkEnv = 'dev' | 'test' | 'pre' | 'prod'
const ENV_GATEWAY: Record<SdkEnv, string> = {
  dev:  'https://dev-gateway.busyming.com',
  test: 'https://test-gateway.busyming.com',
  pre:  'https://pre-gateway.busyming.com',
  prod: 'https://gateway.busyming.com',
}

/** 宿主注入的 httpClient 配置 */
interface HttpClientConfig {
  token: string                      // 访问令牌：SDK 用于 Authorization: Bearer {token}
  env: SdkEnv                        // 环境标识：SDK 据此选择网关 baseURL
}

/** 三接口路径（SDK 内置默认值，对齐后端实际接口路径，宿主可选覆盖） */
interface ApiEndpoints {
  templateList: string               // 默认 '/web/promotion/v1/rule-engine/apportion-template/list'
  configuredInfo: string             // 默认 '/web/promotion/v1/apportion-config/detail'
  departments: string                // 默认 '/api/subsidy/departments'（待后端确认路径）
}

interface SubsidyHostPorts {
  // —— 网络配置（必填）——
  /** 宿主注入 token + env，SDK 内置 httpClient 自行请求三接口 */
  httpClient: HttpClientConfig
  /** 可选覆盖三接口路径（默认值见 ApiEndpoints 注释） */
  endpoints?: Partial<ApiEndpoints>

  // —— 环境能力（可选）——
  /** 埋点钩子：SDK 内所有关键动作（模板选择/打开试算/提交校验/增删承担方…） */
  onTrack?(event: { name: string; payload?: Record<string, unknown> }): void
  /** 异常上报：SDK 内部捕获的不可恢复错误 */
  onError?(error: SdkError): void
  /** Toast/通知代理：缺省用 SDK 内置轻量 Toast；宿主可接管统一风格 */
  notify?(msg: { type: 'error' | 'info'; text: string }): void
}
```

**bizType → applicationDomain 映射**（接口 1 入参，SDK 内置，对齐后端 `applicationDomain` 枚举）：

```ts
const BIZ_TYPE_TO_DOMAIN: Record<BizType, string> = {
  PROMOTION_CAMPAIGN: 'PROMOTION',
  COUPON:             'COUPON',
}
```

**三接口契约**（SDK 内部调用，对齐后端实际接口，宿主无需实现）：

| # | 接口 | 方法 | 入参 | 出参 | 调用时机 |
| --- | --- | --- | --- | --- | --- |
| 1 | 模板列表 | POST | `{applicationDomain, promotionType?, activityPurposeId}` | `ApportionTemplateVO[]` | 挂载时 `loadTemplateList()` |
| 2 | 已配置信息 | POST | `{bizType, bizId}` | `ApportionConfigDetailVO` | 挂载时 `loadConfiguredInfo()` |
| 3 | 部门列表 | GET | `keyword?`（搜索） | `DeptItem[]` | `DepartmentMultiSelect` 展开/搜索时 |

> 接口 3（部门列表）后端文档未明确定义（来源人资系统组织架构），路径待后端确认；返回结构对齐后端 `deptList` 元素：`{deptId, deptCode, deptName}[]`。

**httpClient 实现要点**（core `http-client.ts`）：

1. 基于 axios 封装（宿主已普遍依赖 axios，不增加额外体积；SDK 内部创建独立 instance，不污染宿主全局 axios）；
2. 请求头自动注入 `Authorization: Bearer {token}` + `Content-Type: application/json`；
3. baseURL 由 `ENV_GATEWAY[env]` 决定，拼接 `endpoints` 路径（宿主覆盖或默认值）；
4. 统一错误处理：HTTP 非 2xx → 抛出 `SdkError { code: 'PORTS_FAILURE' }` → `Ports.onError` 上报 + UI 进入可重试错误态；
5. token 不持久化（不写 localStorage/sessionStorage）、不打印日志、不自行刷新；token 失效由宿主在外部刷新后重新传入（SDK 监听 `httpClient.token` 变化重建客户端实例）。

**红线约束（不可协商）**：

1. SDK 仅请求约定三接口（`endpoints` 中的三个路径），不请求任何其他 URL；
2. `token` 全程仅用于 `Authorization` 请求头：不持久化、不打印、不用于其他用途；
3. 宿主未提供 `httpClient` 时，SDK 初始化报错（`httpClient` 为必填项），不降级为无网络模式；
4. 三接口路径默认值集中于 `core/api.ts`，宿主可通过 `endpoints` 覆盖（如网关路由前缀不同）。

内置 httpClient 的收益：宿主仅需注入 token + env，无需为每个数据项实现请求函数，接入成本最低；SDK 可在任意环境（含无后端的设计走查、单测、Storybook）以 Mock httpClient（返回假数据）运行；PRD 15 节权限矩阵落地为「宿主控制 `mode` 与 `disabled`」，SDK 不感知权限；env→网关映射由 SDK 单点维护，宿主无需关心 URL 拼接。

---

## 4. UI 层设计（@scope/subsidy-ui）

### 4.1 组件拆分

```
SubsidySection                      区块根：提供 Store / Ports（provide）
├── SectionHeader                   「配置优惠分摊」标题
├── TemplateSelect                  模板下拉：「自定义」+ httpClient 调接口 1 选项；
│                                   仅记录 ID/名称，不填充内容；usage="templateRule" 时不渲染
├── ApportionModeRadio              分摊方式：按比例分摊 / 按固定金额分摊 / 按券面值分摊
├── FixedModeNotice                 按固定金额说明文案（PRD 9.3：优惠金额按配置顺序
│                                   依次补贴；某承担方补贴后优惠金额小于0，后续不再补贴）
├── CouponFaceValueEditor           仅 apportionMode=COUPON_FACE_VALUE：单门店卡片
│   └── BearerCard（STORE）          承担方=门店（只读）+ 补贴上限=「券面值」只读标签（CapReadonlyLabel）；
│                                   无 apportionPer/fixedAmount/bearMode/部门/SortHandle/RemoveButton
├── BearerList                      承担方列表（横向卡片流，容器查询切换，见 5.2）；COUPON_FACE_VALUE 时不渲染
│   └── BearerCard × n              单个承担方
│       ├── SortHandle              拖拽手柄（按固定金额模式显示，含「补贴顺位 n」徽标）
│       ├── BearerTypeSelect        承担方下拉（已存在类型禁用重复）
│       ├── DepartmentMultiSelect   具体部门（HQ 必填多选；RATIO 模式仅 HQ 渲染；
│       │                           FIXED_AMOUNT 模式 PRODUCT_CENTER/STORE 可渲染且非必填）
│       ├── ApportionPerInput       承担比例（%，inputmode=decimal，两位小数，>0 校验）
│       ├── CapSelect               补贴上限（仅 PRODUCT_CENTER，枚举：不封顶/档案零售价/档案配送价）
│       ├── BearModeLabel           承担方式只读展示（仅按固定金额：末位=「动态补贴」，其余=「固定金额」）
│       ├── FixedAmountInput        承担金额（元，仅 bearMode=FIXED）
│       ├── FieldError              行内红字错误
│       └── RemoveButton            删除（垃圾桶 icon）
├── BearerAddTrigger                「+ 添加承担方」；COUPON_FACE_VALUE 时隐藏
├── TrialTrigger                    「试算」（计算器图标）；COUPON_FACE_VALUE 时隐藏（本模式无试算）
├── ErrorSummary                    「必改错误 n」汇总条（红字 + 标记）
├── OverlayHost                     浮层挂载点（见第 5 章）
│   ├── BearerPickerContent         添加承担方内容（勾选列表，已添加项勾选置灰）
│   └── TrialPanelContent           试算内容（输入优惠金额 → 计算 → 分模式结果列表：按比例=承担金额+比例+上限枚举；按固定=承担金额+承担方式+动态公式）
├── Toast                           内置轻量提示（可被 Ports.notify 接管）
└── SubsidySectionReadonly          只读态（独立轻量组件，见 4.3）
```

基础控件（Select/MultiSelect/Radio/Input/Button/Tag/Popover/Toast）**自研轻量实现**，不引入 Element/Antd 等宿主级组件库——原因：① 避免与宿主组件库版本冲突及样式互相污染；② Shadow DOM 内第三方库的弹层挂载与样式注入均需改造；③ 区块所需控件集合小，自研体积可控（预算见 9.3）。

> 移动端底部抽屉（MobileDrawer）、长按拖拽传感器、滚动穿透处理、移动 H5 只读布局、PlatformContext 与平台判定逻辑、H5 设计令牌均已移除——SDK 不包含任何移动端渲染代码。

### 4.2 编辑态

- **模板下拉**（PRD 9.7，仅 `usage="activityRule"`）：选项 =「自定义」+ httpClient 调接口 1 返回的模板列表（加载中骨架/失败可重试）；用户选择后仅写入 `templateId/templateName`，配置区仍为默认三承担方手动编辑，**不做内容填充**；
- **按比例分摊**（PRD 9.2）：BearerCard 展示「承担比例 apportionPer（必填，>0）+ 按承担方类型条件渲染：PRODUCT_CENTER → 补贴上限 subsidyCap（默认 ARCHIVE_DELIVERY_PRICE）；HQ → 承担部门 deptList（必填多选）」；
- **按固定金额分摊**（PRD 9.3）：顶部展示 `FixedModeNotice` 说明文案；BearerCard 展示「承担方式只读标签 BearModeLabel（末位=「动态补贴」，其余=「固定金额」）+ 承担金额（bearMode=FIXED 时必填，DYNAMIC 时输入框替换为「承接剩余部分」说明文案）+ SortHandle + 补贴顺位徽标 + 部门（HQ 必填、其余非必填）」；排序即扣减顺序，与 PRD「固定金额按顺序依次扣减」一致；**拖拽/添加/删除后自动执行 `deriveBearModes()`，原 DYNAMIC 行变为 FIXED 时金额清空需重新填写**；
- **按券面值分摊**：`CouponFaceValueEditor` 渲染单行门店卡片：承担方=「门店」（只读，不可改/增/删）+ 补贴上限=「券面值」只读标签（subsidyCap=COUPON_FACE_VALUE，不可编辑）；**不渲染「添加承担方」与「试算」按钮**；无 apportionPer/fixedAmount/bearMode/部门/拖拽/删除控件；本模式无必填可编辑字段，校验恒通过；
- 三个承担方初始比例均为空、显示占位「请输入」，全部填写后才允许宿主提交（由 `RATIO_REQUIRED` + `validate()` 保证；COUPON_FACE_VALUE 模式不适用）。

### 4.3 只读态（详情 / 审批页，PRD 9.6 / 14）

`SubsidySectionReadonly`：无输入控件，按原型稿以定义列表/紧凑表格展示「模板（模板名/自定义）/ 分摊方式 / 各承担方（承担比例、补贴上限、承担部门、补贴顺位）」。

- **不区分活动创建来源**（PRD 9.6）：PC 与移动端创建的活动在 PC 详情/审批页均渲染同一份 `ApportionConfig`；移动端来源活动由后端落库 `createMobileDefaultRule()` 等价数据（或宿主兆底传入，见 3.7），SDK 无需感知来源；
- 「指定店铺、指定商品范围」与风险提示属宿主页面自有区块，SDK 不渲染；
- 复用 core 的 types 与文案，不引入编辑态任何交互代码（按需入口，`readonly` 场景宿主可只引该组件，加载体积更小）；
- 审批操作（转办/驳回/通过）按钮属宿主页面，SDK 只读区块不包含；
- PRD 17.2 待定项「审批页是否展示校验提示/试算入口」：预留 props `showTrialEntryInReadonly`（默认 false），确认后仅改默认值；
- `value=null`（规则缺失）时渲染空态「未配置补贴规则」（PRD 17.8 空态规范待定，先以该默认值实现）。

### 4.4 错误态

| 层级 | 表现形式 | 来源 |
| --- | --- | --- |
| 行内 | 字段下方红字（如「请输入」「请设置」「承担比例需大于0」） | `errors[].target` |
| 区块 | 区块底部红字 + 「必改错误」标记（如「承担比例需为100%，当前85.00%」） | 无 target 的 error |
| 汇总 | 「必改错误 n »」计数条，点击滚动定位首个错误 | errors 聚合 |
| 行为阻止 | 删除阻止 toast、试算前置 toast、提交 `validate()` 返回 false | Actions / Validator |
| 轻提示 | 「轻触提示 n »」（warning 级，预留给产品扩展，如建议性文案） | level=warning |

### 4.5 PRD 9.4 交互规则 → 实现映射总表

| # | PRD 规则 | 实现位置 | 测试 |
| --- | --- | --- | --- |
| 1 | 默认三承担方；Picker 内已勾选置灰 | `initDefaultBearers` + `BearerPickerContent` | core 单测 + e2e |
| 2 | 试算前置校验 | Validator `TRIAL_PRECHECK` | core 单测 |
| 3 | 最后一个承担方自动补齐；手动改后不再补齐 | `autoFillLastApportionPer` 状态机 | core 单测（等价类全覆盖） |
| 4 | 删除后重算补齐；剩 1 个阻止删除 toast | `removeBearer` | core 单测 + e2e |
| 5 | 固定金额末位始终是动态补贴（顺位自动推导） | `deriveBearModes()` Action（3.2）+ `BearModeLabel` 只读展示 | core 单测（add/remove/reorder 等价类）+ e2e |
| 6 | 模板可手动选择/切自定义，修改不存回模板 | `selectTemplate` Action（3.5）+ `TemplateSelect` 下拉 | core 单测 + e2e |
| 7 | 红字 + 必改错误标记 | ErrorSummary / FieldError | UI 组件测试 + 视觉比对 |
| 8 | 保存/提交归宿主；生效后生成新版本 | 命令式 API（§6.4）；版本由后端处理 | 契约测试 |

### 4.6 数据通道（httpClient 取数）

UI 组件（如 `DepartmentMultiSelect`、`TemplateSelect`）通过 provide/inject 拿到 core 的 `api` 模块（封装 httpClient），**组件本身不感知 token/env/网关映射**。取数逻辑（core `api.ts` 提供，UI 复用）：

```ts
// core/api.ts —— UI 层唯一取数入口，封装三接口调用（对齐后端接口路径与方法）
import { createHttpClient } from './http-client'

export function createApi(ports: SubsidyHostPorts) {
  const client = createHttpClient(ports.httpClient, ports.endpoints)

  return {
    /** 接口 1：模板列表（POST，对齐后端 listApportionTemplates） */
    fetchTemplateList(params: {
      bizType: BizType
      promotionType?: string
      activityPurposeId?: number
    }): Promise<ApportionTemplateVO[]> {
      return client.post('/web/promotion/v1/rule-engine/apportion-template/list', {
        applicationDomain: BIZ_TYPE_TO_DOMAIN[params.bizType],
        promotionType: params.promotionType,
        activityPurposeId: params.activityPurposeId,
      })
    },
    /** 接口 2：已配置信息（POST，对齐后端 apportion-config/detail） */
    fetchConfiguredInfo(params: { bizType: BizType; bizId: string }): Promise<ApportionConfigDetailVO> {
      return client.post('/web/promotion/v1/apportion-config/detail', params)
    },
    /** 接口 3：部门列表（GET，待后端确认路径） */
    fetchDepartments(query?: { keyword?: string }): Promise<DeptItem[]> {
      return client.get('/api/subsidy/departments', query)
    },
  }
}
```

要点：

- **单一取数入口**：三接口调用收敛在 `api.ts`，UI 组件零分支、零 url 感知；
- **httpClient 流向**：`ports.httpClient.token` → `Authorization: Bearer {token}` 请求头；`ports.httpClient.env` → `ENV_GATEWAY[env]` baseURL；`ports.endpoints` → 可选路径覆盖；
- **使用场景对照**：正常接入 → 宿主传入 `httpClient: { token, env }`；设计走查/单测 → 以 Mock httpClient（返回假数据）注入；
- **网络层验证**：单测断言 SDK 产物仅请求约定三接口路径，不请求任何其他 URL（CI 静态检查，见 10 节）。

---

## 5. 单端（PC）适配方案

### 5.1 端形态

SDK 收敛为**纯 PC 单端**：编辑态与只读态均仅支持 PC Web。

| 端 | 编辑态 | 只读态 | 说明 |
| --- | --- | --- | --- |
| PC 管理后台 | ✔（全部交互：模板选择、拖拽、浮层试算） | ✔（详情/审批） | SDK 唯一交付目标 |
| 移动 H5 | ✘ | ✘ | 不再渲染（含审批页）；移动端审批的展示诉求由宿主自行处理或不展示 |
| 小程序（三个） | ✘ | ✘ | PRD 14.2 不进入 |

- 不设 `platform` prop 与平台判定逻辑，SDK 假定运行于 PC 桌面浏览器环境；
- 移动端创建的活动由后端按 `createMobileDefaultRule()` 口径落库默认规则（3.7），其分摊明细在 **PC** 详情/审批页正常回显——「移动端不展示」指 SDK 不在移动端渲染，不影响数据口径与 PC 侧查看；
- 若二期出现移动端配置/展示诉求（PRD 17.7），重新评估后再引入平台适配层，core 领域模型不受影响。

### 5.2 容器宽度自适应

区块是**页面内嵌件**，宿主可能在 PC 页面开出窄栏或弹窗内嵌，布局断点必须基于**区块容器自身宽度**而非视口：

- **布局切换基于 CSS 容器查询**（`container-type: inline-size` 设于区块根）：`≥ 768px` 横向卡片流（grid，`minmax(280px, 1fr)` 自动换行），`< 768px` 承担方卡片全宽纵向堆叠；对不支持容器查询的旧浏览器以 ResizeObserver 回退写 `data-layout` 属性选择器（一份样式两种选择器出口，构建时自动生成）；
- 字号/间距使用设计令牌（CSS 变量），仅 PC 一套默认值；
- 卡片内部字段栅格：卡片内字段纵向堆叠；
- **px 体系**：SDK 内部统一 px（不依赖宿主 `html{font-size}` 的 rem 约定），`:host` 设定基准字号——宿主无论采用何种布局方案，SDK 区块视觉尺寸一致。

### 5.3 浮层策略

编辑态浮层容器统一为 `PcPopoverPanel`（移动底部抽屉方案已移除）：

| 功能 | 容器 |
| --- | --- |
| 试算 | 浮层面板：默认锚定「试算」按钮右侧展开，宽 480px；`placement: 'left' \| 'right' \| 'auto'`，防溢出自动翻转 |
| 添加承担方 | 浮层面板（勾选列表，已添加项勾选置灰） |
| 删除确认 | 气泡确认（或直接删除 + toast，与原型一致） |
| Toast | 区块顶部居中 |

实现：

```ts
// overlay/OverlayStrategy.ts（PC 单策略）
interface OverlayStrategy {
  container: Component            // PcPopoverPanel
  anchorToTrigger: boolean        // true
  placement: 'left' | 'right' | 'auto'
}
```

`OverlayHost` 依据 `state.overlay` 决定渲染哪份内容，同一时刻仅一个浮层（单例互斥，打开试算自动关闭 Picker）。浮层打开/关闭动作触发 `Ports.onTrack` 埋点。

### 5.4 拖拽排序

- 统一基于 **Pointer Events** 实现 `useSortable`（不引入 sortablejs 等第三方依赖，避免 Shadow DOM 兼容问题与额外体积）；
- 拖拽手柄 pointerdown 即激活（移动端长按激活逻辑已随编辑态下线移除）；
- 拖动过程仅更新 ui 态（位移 transform），drop 时一次性提交 `reorderBearers(from, to)` → 更新 `sortIndex` 序列与「补贴顺位 n」徽标 → 执行 `deriveBearModes()`（新末位→DYNAMIC、原末位→FIXED 且金额清空）→ 触发试算结果缓存失效；
- 全程不操作宿主 DOM（拖拽幻影元素渲染在 Shadow Root 内）。

---
## 6. 框架适配层

三端暴露**完全一致的逻辑 API**（同名 props / 事件 / 命令式方法），仅有框架惯用法差异。完整对照表见 6.4。

### 6.1 Vue 3 宿主（`@scope/subsidy-vue`）

原生体验最佳路径，直接消费 UI 产物①（不经 Web Component，无额外运行时）：

```vue
<script setup lang="ts">
import { SubsidySection } from '@scope/subsidy-vue'
import type { ApportionConfig, SubsidyHostPorts } from '@scope/subsidy-vue'

const config = ref<ApportionConfig>()
const sectionRef = ref()
const ports: SubsidyHostPorts = {
  // 宿主注入 token + env，SDK 内置 httpClient 自行请求三接口
  httpClient: {
    token: authStore.accessToken,
    env: import.meta.env.VITE_SDK_ENV,  // 'dev' | 'test' | 'pre' | 'prod'
  },
  onTrack: (e) => tracker.log(e.name, e.payload),
  onError: (e) => errorReporter.capture(e),
}

async function beforeHostSubmit() {
  const { valid } = await sectionRef.value.validate()
  if (!valid) return false
  return { apportionConfig: sectionRef.value.getPayload() }  // 并入活动表单提交体
}
</script>

<template>
  <SubsidySection
    ref="sectionRef"
    v-model:value="config"
    mode="edit"
    usage="activityRule"
    biz-type="PROMOTION_CAMPAIGN"
    :biz-id="bizId"
    :activity-purpose-id="activityPurposeId"
    :promotion-type="promotionType"
    :ports="ports"
    @error-change="onErrors"
  />
</template>
```

- 支持 `v-model:value`（半受控：SDK 内部持有编辑态，变化时同步出去；宿主不强制回写）；
- 也可 `app.use(SubsidyPlugin)` 全局注册；
- peerDependencies: `vue ^3.2.0`，SDK 不携带 Vue 运行时。

### 6.2 Vue 2 宿主（`@scope/subsidy-vue2`）

Vue 2 页面通过包装组件使用编译产物②（Web Component）。包装组件以 render 函数创建元素，规避 `ignoredElements` 配置，并处理「对象走 property、回调走事件」的桥接：

```js
import SubsidySection from '@scope/subsidy-vue2'

export default {
  components: { SubsidySection },
  methods: {
    async beforeHostSubmit() {
      const { valid } = await this.$refs.subsidy.validate()
      if (!valid) return false
      return { subsidyRule: this.$refs.subsidy.getPayload() }
    },
  },
  template: `
    <SubsidySection ref="subsidy" mode="edit" usage="activityRule"
      biz-type="COUPON"
      :biz-id="bizId"
      :value="config" :ports="ports" @change="config = $event" />`,
}
```

实现要点（封装在包内，宿主无感）：

- `mounted` 中将对象型 props 以 **property** 赋给元素（`el.value = ...`，绕过 attribute 仅支持字符串的限制），`watch` 同步后续变更；
- SDK 抛出的 `CustomEvent` 桥接为 Vue2 组件 `$emit`；
- 命令式方法直接代理到元素实例；
- 对老旧构建链（webpack 4 + babel）提供转译到 ES2017 的独立产物入口。

### 6.3 React 宿主（`@scope/subsidy-react`）

React 18 及以下对 Custom Element 仅支持字符串 attribute、不支持自定义事件，故提供薄封装（`< 5KB`）：

```tsx
import { useRef } from 'react'
import { SubsidySection, type SubsidySectionHandle } from '@scope/subsidy-react'

export function PromotionForm() {
  const ref = useRef<SubsidySectionHandle>(null)

  const beforeHostSubmit = async () => {
    const { valid } = await ref.current!.validate()
    if (!valid) return false
    return { apportionConfig: ref.current!.getPayload() }
  }

  return (
    <SubsidySection
      ref={ref}
      mode="edit"
      usage="activityRule"
      bizType="PROMOTION_CAMPAIGN"
      bizId={bizId}
      activityPurposeId={activityPurposeId}
      promotionType={promotionType}
      defaultValue={config}
      ports={ports}
      onChange={setConfig}
      onErrorChange={setErrors}
    />
  )
}
```

封装实现要点：

- `useLayoutEffect` 内将对象 props 赋为元素 property、以 `addEventListener` 绑定 `on*` 回调，卸载时完整移除；
- `forwardRef + useImperativeHandle` 暴露 `validate / getPayload / reset / setValue`；
- StrictMode 双挂载安全（注册守卫 + 订阅幂等）；
- React 19 原生支持 Custom Elements，本封装依然保留以保证 API 一致与旧版本兼容；
- peerDependencies: `react >= 16.8`，零额外运行时依赖。

### 6.4 三端 API 对照表

| 能力 | Vue 3 | Vue 2 | React |
| --- | --- | --- | --- |
| 初始值 | `:value` / `v-model:value` | `:value` | `defaultValue`（非受控） |
| 模式 | `mode="edit\|readonly"` | 同左 | 同左 |
| 使用场景 | `usage="activityRule\|templateRule"` | 同左 | 同左 |
| 业务域 | `biz-type="PROMOTION_CAMPAIGN\|COUPON"` | 同左 | `bizType` |
| 业务 ID | `:biz-id="id"` | 同左 | `bizId={id}` |
| 活动目的 ID | `:activity-purpose-id="id"` | 同左 | `activityPurposeId={id}` |
| 活动类型 | `:promotion-type="type"` | 同左 | `promotionType={type}` |
| 数据注入 | `:ports="ports"` | 同左 | `ports={ports}` |
| 主题 | `:theme="tokens"` | 同左 | `theme={tokens}` |
| 变更事件 | `@change` | `@change` | `onChange` |
| 错误事件 | `@error-change` | `@error-change` | `onErrorChange` |
| 试算完成 | `@trial-complete` | `@trial-complete` | `onTrialComplete` |
| 校验 | `ref.validate(): Promise<{valid, errors}>` | 同左 | `ref.current.validate()` |
| 取提交体 | `ref.getPayload(): ApportionSubmitPayload` | 同左 | `ref.current.getPayload()` |
| 重置/赋值 | `ref.reset()` / `ref.setValue(c)` | 同左 | 同左 |
| 销毁 | 组件卸载自动 | 组件 `$destroy` 自动 | 组件卸载自动 |

`ApportionSubmitPayload = ApportionConfig & { submittedAt: string }`：包含 ruleId/version 透传字段与 **`templateId/templateName`（用户下拉选中的模板，选「自定义」时为 null；PRD 12.2 报表「规则来源」列由后端按 templateId 是否非空推导）**；**规则版本生成由后端在活动生效后修改时处理**（PRD 9.4-8 / 16-3），SDK 不实现版本逻辑。序列化时剥离前端状态字段（id/apportionPerSource/sortIndex），金额分→元转换，数组按顺位排序（见 3.1 序列化约定）。

### 6.5 规则引擎宿主接入（模板编辑模式）

PRD 9.7 要求规则引擎「规则类型」勾选「分摊规则」后显示「配置优惠分摊」模块。该场景下 SDK 以模板编辑模式嵌入：

```tsx
// 规则引擎（React 示例）：编辑的是分摊模板本身
<SubsidySection
  ref={ref}
  mode="edit"
  usage="templateRule"          // 关键：不渲染 TemplateSelect 模板下拉
  bizType="PROMOTION_CAMPAIGN"
  defaultValue={templateDraft}   // 既有模板回显
  ports={ports}                  // 仍需 httpClient（部门接口 3 可用）；模板下拉不渲染故接口 1 不调用
/>
// 提交：ref.current.getPayload() → 模板内容（apportionMode + bearers 明细），
// 由宿主并入引擎规则表单；唯一性校验（同应用领域 × 同条件配置 × 规则类型）由引擎后端执行（PRD 9.7）
```

与场景①的差异仅两点：无模板选择栏、payload 语义为「模板内容」而非「活动规则实例」。编辑交互、校验规则、试算能力完全一致（试算对模板验证同样有意义）。

---

## 7. 样式隔离与主题

### 7.1 主方案：Shadow DOM（elements 产物）

`defineCustomElement` 将每个 SFC 的样式编译注入其 Shadow Root，获得双向隔离：宿主全局 CSS（含 `* { margin: 0 }` 这类 reset）不影响 SDK；SDK 样式亦不泄漏至宿主。

配套风险对策（逐条落实为工程约束）：

| 风险 | 对策 |
| --- | --- |
| 浮层 Teleport 到 body 会逃出隔离 | **禁止 Teleport 至 body**：浮层渲染在 Shadow Root 内的 fixed 容器（`OverlayHost`），z-index 在 Shadow 内自治 |
| 宿主祖先链存在 `transform/filter/perspective` 导致 fixed 失效 | 打开浮层时向上遍历检测，命中则将浮层改用绝对定位 + 滚动跟随；并在接入文档中约束宿主避免在 SDK 祖先使用此类样式 |
| 宿主全局字体/图标字体不生效 | SDK 自带基准排版（`:host { font: 14px/1.5 ... }`），图标全部 **inline SVG**（杜绝字体图标跨 Shadow 失效） |
| 宿主想定制主题 | CSS 自定义属性天然穿透 Shadow 边界（见 7.3） |
| Vue 3 宿主直引组件库产物无 Shadow | 产物①采用与降级方案相同的类名前缀隔离（7.2），因为此时宿主是同构 Vue3 工程、样式冲突面可控 |

### 7.2 降级方案：Light DOM + 严格命名空间

同一套源码的第二条样式管道（构建时 postcss 处理，源码零分叉）：

1. 所有类名加 `.ss-` 前缀（CSS Modules hash 前缀固定 `ss`）；
2. 全部选择器以 `:where(.ssdk-root)` 包裹提升一层特异性的同时便于宿主覆写；
3. 根节点 `all: initial` 重置 + 内建局部 reset（仅作用于 `.ssdk-root` 子树）；
4. 不输出任何裸标签选择器、不输出 `@font-face` 到全局、不注入全局变量（变量挂在 `.ssdk-root`）。

适用：产物①（Vue 3 直引版）与确遇 Shadow 兼容问题的宿主。切换方式为换包名导入，API 不变。

### 7.3 主题定制（CSS Variables）

```css
/* 宿主可在任意祖先节点覆写（穿透 Shadow） */
.my-host-theme {
  --ss-color-primary: #ff6a00;      /* 主色（按钮/链接/激活态，默认对齐设计稿橙） */
  --ss-color-error: #f5222d;
  --ss-radius-card: 8px;
  --ss-font-size-base: 14px;
  --ss-z-index-overlay: 1000;       /* 与宿主弹层体系对齐层级 */
}
```

令牌分三层：`color / radius / font / spacing / z-index`，仅 PC 一套默认值。品牌化需求（如企业门户主题色）仅改 `--ss-color-primary` 即可整体生效。

### 7.4 图标与字体

- 图标：构建期将 SVG 内联为组件（`~1KB/个`），无网络请求、无跨 Shadow 字体问题；
- 字体：不引入自定义字体文件，跟随系统字体栈；
- 单位：内部 px/em（px 体系说明见 5.2）。

---

## 8. SDK 与宿主的边界与解耦

### 8.1 职责边界表

| 职责 | SDK | 宿主 | 后端 |
| --- | --- | --- | --- |
| 「配置优惠分摊」区块渲染与交互 | ✔ | | |
| 校验规则、错误文案、试算计算 | ✔（core 单点） | | 复用 core/calculator |
| 模板下拉选择与 ID/名称记录 | ✔（TemplateSelect + selectTemplate + httpClient POST 接口 1） | ✔（传入 `httpClient` 配置 + `activityPurposeId`/`promotionType` prop） | ✔（模板数据源） |
| 模板自动匹配/推荐（活动类型 × 活动目的 × 启用，PRD 9.7） | | ✔（宿主在 SDK 外部执行，结果经 `value.templateId` 传入） | ✔（匹配算法） |
| 承担方枚举 / 部门 / 模板数据 | ✔（承担方枚举 SDK 内置硬编码；部门/模板由 httpClient 调接口获取） | ✔（传入 `httpClient` 配置） | ✔（数据源） |
| 数据获取通道（httpClient） | ✔（内置 httpClient，自行请求约定三接口） | ✔（注入 `token` + `env`，可选覆盖 `endpoints`） | ✔（API 与鉴权） |
| 模板存储、列表管理、唯一性校验 | 提供模板编辑界面（`usage="templateRule"`） | ✔（引擎表单集成） | ✔（规则引擎） |
| 移动端默认规则（门店 100%） | ✔（`createMobileDefaultRule` 数据工厂，与渲染端无关） | ✔（移动端活动创建时调用/透传） | ✔（推荐落库，供 PC 详情/审批统一回显） |
| 审批页「指定店铺、指定商品范围」区块 | | ✔ | ✔ |
| 移动端（小程序 + 移动 H5）分摊明细展示 | | ✔（宿主自行处理或不展示） | |
| 保存草稿 / 提交按钮与表单提交流程 | 提供 `validate()`/`getPayload()` | ✔ | ✔ |
| 规则存储、版本生成、历史版本 | 透传 ruleId/version | | ✔ |
| 审批页转办/驳回/通过 | | ✔ | ✔ |
| 权限控制（能否编辑/数据范围） | 响应 `mode`/`disabled` | ✔（权限点判断） | ✔ |
| 埋点上报通道 | 产生事件 | ✔（onTrack 通道） | |
| T+1 计费、退款逆向计费、核验看板、补贴报表 | | | ✔ |

### 8.2 宿主环境零污染约束清单（Code Review 红线）

1. **无全局变量**：不挂 `window.*`（customElements 注册名除外，且带重复注册守卫）；
2. **无全局样式**：见第 7 章；（移动端编辑态下线后，原「移动抽屉打开时临时锁定 body 滚动」的例外条款同步移除，SDK 对宿主样式零触碰）；
3. **无全局事件残留**：所有 `window/document` 监听在 `disconnectedCallback` / 卸载钩子中移除；`destroy()` 后不留定时器、不残留 DOM；
4. **无 Polyfill 注入**：SDK 构建目标 ES2017+，需要的 `ResizeObserver` 等能力做特性检测并在不支持时优雅降级（容器查询回退方案见 5.2），不打包 core-js；
5. **网络请求受控**：SDK 内置 httpClient（基于 axios 封装，独立 instance），仅请求约定三接口（模板列表 / 已配置信息 / 部门列表），不请求任何其他 URL；`token` 仅用于 `Authorization` 请求头，不持久化、不打印、不自行刷新；宿主未提供 `httpClient` 时 SDK 初始化报错，不降级为无网络模式（3.8 / 4.6）；
6. **无跨实例状态**：多实例并存由 `createSectionStore` 工厂保证（3.2），任何模块级可变状态禁止合入；
7. **无原型链修改 / 无依赖冲突**：运行时依赖清零（Vue runtime 仅存在于 elements 产物内部并与宿主隔离）；`package.json` 声明 `"sideEffects": ["*.css"]` 支持 tree-shaking；
8. **错误不扩散**：SDK 内部异常一律捕获 → `Ports.onError` 上报 + 区块降级为只读展示并提示「分摊配置加载异常」，绝不让异常冒泡击穿宿主页面（宿主可另行配置宿主级 ErrorBoundary/错误监听）。

### 8.3 数据流与保存时序（PRD 9.4-8 / 9.7 / 17.4）

```
宿主页面加载（活动/券配置页）
  → <SubsidySection :ports="{ httpClient: { token, env } }" :biz-type="bizType"
                    :biz-id="bizId" :activity-purpose-id="activityPurposeId"
                    :promotion-type="promotionType">
  → SDK 内部（挂载后并行）：
      ① loadConfiguredInfo()（httpClient POST 接口 2，传 {bizType, bizId}）
         ├─ 成功 → 反序列化重建状态（含 templateId/templateName 回显下拉选中项）
         ├─ 失败 → 回退 initDefaultBearers() 默认三承担方 + onError
         └─ value prop 非空时优先使用 value（覆盖/兆底，不走接口 2）
      ② loadTemplateList()（httpClient POST 接口 1，传 {applicationDomain, promotionType?, activityPurposeId}）
         ├─ 成功 → 填充模板下拉选项
         └─ 失败 → 下拉错误态可重试，不阻塞配置

编辑过程
  → 用户可从模板下拉选择模板（仅写入 templateId/templateName，不填充内容）
  → 部门多选展开时 → httpClient 调接口 3（传 keyword）
  → SDK 内部状态机 + 即时校验 → @change / @error-change 通知宿主

宿主点击「保存草稿 / 提交创建」（宿主按钮）
  → await ref.validate()
      ✗ → SDK 展示错误（红字+必改错误），宿主中止提交流程
      ✓ → ref.getPayload() → 序列化（剥离前端状态字段 + 金额分→元 + 数组按顺位排序）
        → 宿主并入活动表单 body 的 apportionConfig 字段 → hostApi.saveActivity()
        （payload 含 templateId/templateName，报表「规则来源」列由后端推导）
  → 后端落库规则；活动生效后再修改 → 后端生成新规则版本（SDK 不参与）

详情/审批页（PC）
  → <SubsidySection mode="readonly" :ports="{ httpClient: { token, env } }"
                    :biz-type="bizType" :biz-id="bizId">
  → SDK 内部：loadConfiguredInfo()（POST 接口 2，传 {bizType, bizId}）拉取已配置信息 → 只读渲染
  → 审批操作（转办/驳回/通过）属宿主页面
```

草稿态是否落库（PRD 17.4 待定）对 SDK 透明：落库则接口 2 返回数据回显，不落库则宿主自行缓存 payload 并通过 `value` prop 传入。

**时序图（Mermaid）**：

```mermaid
sequenceDiagram
    participant Host as 宿主页面
    participant SDK as SubsidySection SDK
    participant Store as SectionStore
    participant HTTP as httpClient (axios)
    participant BE as 后端 API

    Note over Host,BE: ① 初始化阶段（挂载后并行）
    Host->>SDK: 传入 props {bizType, bizId, activityPurposeId, ports:{httpClient:{token,env}}}
    SDK->>Store: createSectionStore(options)
    par 并行加载
        Store->>HTTP: POST /web/promotion/v1/rule-engine/apportion-template/list
        HTTP->>BE: {applicationDomain, promotionType?, activityPurposeId}
        BE-->>HTTP: ApportionTemplateVO[]
        HTTP-->>Store: 填充 templates.options
    and
        Store->>HTTP: POST /web/promotion/v1/apportion-config/detail
        HTTP->>BE: {bizType, bizId}
        BE-->>HTTP: ApportionConfigDetailVO
        HTTP-->>Store: 反序列化写入 config（补齐 id/sortIndex/apportionPerSource）
    end
    Store-->>SDK: 状态更新 → UI 渲染

    Note over Host,BE: ② 编辑过程
    Host->>SDK: 用户操作（选模板/填比例/拖拽/添加删除承担方）
    SDK->>Store: Actions（selectTemplate / setBearerApportionPer / deriveBearModes / reorderBearers）
    Store->>Store: 状态机 + 即时校验（Validator）
    Store-->>SDK: @change / @error-change 通知宿主
    opt 部门多选展开
        SDK->>HTTP: GET /api/subsidy/departments?keyword=xxx
        HTTP->>BE: 请求部门列表
        BE-->>HTTP: DeptItem[]
        HTTP-->>SDK: 填充 DepartmentMultiSelect 下拉
    end

    Note over Host,BE: ③ 提交流程
    Host->>SDK: await ref.validate()
    SDK->>Store: submitValidate()
    Store-->>SDK: {valid, errors}
    alt 校验失败
        SDK-->>Host: valid=false，SDK 展示错误（红字+必改错误）
        Host->>Host: 中止提交
    else 校验通过
        Host->>SDK: ref.getPayload()
        SDK->>Store: 序列化（剥离 id/apportionPerSource/sortIndex，金额分→元，数组按顺位排序）
        Store-->>SDK: ApportionSubmitPayload
        SDK-->>Host: payload
        Host->>BE: 宿主并入活动表单 body.apportionConfig → 提交
        BE-->>Host: 落库成功（同事务保存单据 + 分摊配置）
    end

    Note over Host,BE: ④ 详情/审批页（只读态）
    Host->>SDK: mode="readonly", bizType, bizId
    SDK->>HTTP: POST /web/promotion/v1/apportion-config/detail
    HTTP->>BE: {bizType, bizId}
    BE-->>HTTP: ApportionConfigDetailVO
    HTTP-->>SDK: 反序列化 → 只读渲染
```

### 8.4 异常兜底

| 场景 | 行为 |
| --- | --- |
| httpClient 请求失败（如部门接口超时） | 对应控件进入可重试的错误态（「加载失败，点击重试」），不阻塞其他字段；`SdkError { code: 'PORTS_FAILURE' }` → onError 上报 |
| **模板列表加载失败 / 超时** | 下拉进入可重试错误态（`template_load_failed` 埋点 + onError 上报）；不阻塞配置流程（仍可手动配置承担方，模板保持「自定义」） |
| **已配置信息加载失败** | 回退为默认三承担方初始态 + onError 上报 + 提示「配置加载失败」；宿主可通过 `value` prop 兜底传入 |
| `value` 反序列化失败（脏数据） | 捕获 → onError → 回退为默认三承担方初始态并提示，保证宿主页面可用 |
| 试算引擎输入异常 | 防御性返回 `items: []` + onError，UI 展示「试算失败，请重试」 |
| SDK 根级渲染异常 | 区块降级为只读占位 + 上报，不影响宿主表单其余部分提交 |
| token 失效（401） | httpClient 捕获 401 → onError 上报「认证失效」；宿主在外部刷新 token 后重新传入，SDK 监听 `httpClient.token` 变化重建客户端实例 |

---

## 9. 构建、发布与版本管理

### 9.1 产物规格

| 包 | 入口 | 格式 | 关键配置 |
| --- | --- | --- | --- |
| `@scope/subsidy-core` | `index`、`calculator`、`default-rule`（子路径） | ESM + CJS + d.ts | tsup 构建；target ES2017；`sideEffects: false`；peerDependencies: `axios >= 0.21` |
| `@scope/subsidy-vue` | `index` | ESM + d.ts | Vite library mode；`external: ['vue']` |
| `@scope/subsidy-elements` | `index`（ESM）、`cdn`（IIFE） | ESM + IIFE + d.ts | Vue runtime 内联打包；IIFE 供 `<script>` 直引兜底 |
| `@scope/subsidy-vue2` | `index` | ESM（另附 ES2017 转译入口 `legacy`） + d.ts | 依赖 elements |
| `@scope/subsidy-react` | `index` | ESM + d.ts | `external: ['react', 'react-dom']`；依赖 elements |

- 类型统一由 `vue-tsc` / `tsc` 产出 d.ts，`core` 的类型为唯一事实源，各 adapter 包 `export type * from '@scope/subsidy-core'` 再导出，杜绝多端类型漂移；
- 所有包发布前执行 `publint` + `arethetypeswrong` 校验。

### 9.2 发布流程

1. pnpm workspace + **changesets**：每个 PR 附带 changeset 描述变更级别；
2. CI（ lint → 单测 → 构建 → e2e ）通过后，release workflow 自动计算版本、生成 CHANGELOG、发布至企业私有 registry；
3. 通道：`beta` 标签供业务域灰度接入，稳定后 promote 为 `latest`；
4. **语义化版本承诺**：1.x 内 props / 事件 / 命令式 API / Ports 接口向后兼容；破坏性变更（如错误码重命名）必须 major + 迁移指南；
5. **core/calculator 与后端计费引擎共版本**：服务端以精确版本号依赖，升级需双方对齐回归 PRD 10.4 算例；**`default-rule` 子路径同样纳入共版本管理**（后端落库移动端默认规则时引用，保证口径一致）。

### 9.3 体积与性能预算（gzip）

| 产物 | 预算 | 说明 |
| --- | --- | --- |
| core | ≤ 18 KB | 纯逻辑（含默认规则工厂 + httpClient 封装）；axios 为 peerDependency（宿主已依赖，不重复打包），可独立用于 Node |
| vue（不含 vue runtime） | ≤ 40 KB | 移动端相关代码已全部移除，预算下调 |
| elements（含 Vue runtime） | ≤ 82 KB | Vue2/React 宿主一次性成本，建议宿主路由级懒加载 |
| vue2 / react adapter | ≤ 5 KB | 薄封装 |

性能要求：区块首渲染 ≤ 100ms（PC Chrome 中位）；浮层打开 ≤ 16ms 首帧；模板列表加载在挂载后异步进行，下拉骨架占位不阻塞首渲染；`validate()` 为同步规则的全量遍历（承担方数量级为个位数），耗时忽略；编辑态仅在必要时渲染浮层内容（v-if），多实例页面内存随实例数线性增长且无共享泄漏。

---

## 10. 测试方案

| 层 | 工具 | 覆盖内容 |
| --- | --- | --- |
| 单元测试 | Vitest | ① 校验引擎：§3.3 全部规则码 × 触发时机矩阵（含 `RATIO_POSITIVE` 与 `DEPT_REQUIRED` 双模式差异；）；② 自动补齐状态机等价类（§3.4）；③ 计算引擎：按比例/固定金额顺序扣减/动态兆底/精度边界（99.99、100.01、分单位进位）；④ Store 多实例隔离；⑤ **模板下拉：httpClient POST 接口 1 加载/选择写入 ID+名称/切自定义置 null/加载失败重试/停用模板回显**；⑥ **`createMobileDefaultRule` 快照测试**；⑦ **httpClient：env→网关映射/token→Authorization 头/三接口路径/endpoints 覆盖/401 处理**；⑧ **`deriveBearModes` 顺位推导：add/remove/reorder 后末位=DYNAMIC、原末位=FIXED 且 fixedAmount 清空、单行边界**；⑨ **`COUPON_FACE_VALUE` 模式：setApportionMode 切入重置单门店+subsidyCap=COUPON_FACE_VALUE/切出恢复三承担方/校验恒通过/无试算** |
| Golden Case | Vitest 数据集 | **PRD 10.4 四笔算例订单**（S103E…/S104F…/S101L…/S109A…）转为 JSON 数据集，试算结果与业务确认值逐分比对；后端计费引擎共用同一数据集保证口径 |
| 组件测试 | @vue/test-utils + happy-dom | 模板下拉渲染与选中态、错误汇总定位、Picker 置灰逻辑、只读态渲染（**含移动端默认规则回显**）；**COUPON_FACE_VALUE 模式：单门店卡片+券面值只读标签+隐藏添加/试算按钮** |
| 跨宿主契约测试 | Vitest | 三端 adapter 对同一组操作产出一致的事件序列与 payload（6.4 对照表逐行断言，**含 usage 三端一致性**） |
| E2E | Playwright | **同一套交互脚本**跑在 examples 的 vue2/vue3/react 三个 PC 宿主上：模板下拉选择→验证 payload 仅含 templateId/templateName 且配置内容未变→切自定义→填比例（验证自动补齐与 >0 校验）→ 试算 → 切固定金额（验证末位=动态补贴只读标签、拖拽后顺位推导与金额清空）→ 拖拽排序 → 删除阻止 toast → **切按券面值（验证单门店+券面值只读+无添加/试算按钮+payload 正确）**；只读用例验证 PC 审批页布局 |
| 视觉回归 | Playwright 截图比对 | 对齐 PC 设计稿关键态（默认态、**模板下拉展开/选中态**、错误态、试算面板、只读态） |
| 性能 | Lighthouse CI（examples） | FCP/TTI 基线监控，elements 产物加载体积门禁 |
| 网络层静态检查 | ESLint 规则 + 依赖图扫描 | 断言 SDK 产物仅请求约定三接口路径（`core/api.ts` 中的三个 URL），不请求任何其他 URL；`token` 无持久化（localStorage/sessionStorage）/打印调用；axios 仅通过 `core/http-client.ts` 创建独立 instance，禁止引用宿主全局 axios |

---

## 11. PRD 开放问题（第 17 节）的 SDK 默认策略

| PRD 待定项 | SDK 默认实现 | 确认后的变更成本 |
| --- | --- | --- |
| 17.1 试算口径与展示字段 | 试算为前端计算、分模式展示：按比例=承担金额+承担比例+补贴上限枚举（仅 PRODUCT_CENTER）；按固定金额=承担金额+承担方式+动态补贴公式；`TrialResultItem` 含 `apportionPer/subsidyCap/bearMode/reason` 展示字段 | 仅改展示，不动结构 |
| 17.2 审批页是否展示校验/试算入口 | `showTrialEntryInReadonly`（默认 false）、只读态不渲染错误 | 改默认值 |
| 17.3 生效后修改的二次确认与版本历史 | 宿主职责；SDK payload 透传 `ruleId/version` | 零 SDK 改动 |
| 17.4 草稿是否落库 | 对 SDK 透明（8.3） | 零 SDK 改动 |
| 17.5 权限矩阵与数据范围 | 宿主以 `mode/disabled/Ports 数据` 表达 | 零 SDK 改动 |
| 17.6 优惠券计算中配送价是否取快照 | SDK 无档案价数据来源，TrialContext 已移除；补贴上限（SubsidyCap）仅作为配置项写入 payload，上限执行由后端 T+1 计费引擎保障（后端拥有价格快照数据） | 零 SDK 改动 |
| 17.7 移动端默认「门店承担 100%」二期是否可配置 | `createMobileDefaultRule()` 为工厂函数而非散落的硬编码；二期若开放配置，扩展工厂参数即可（SDK 纯 PC，移动端配置载体需另行评估） | 零/小改动 |
| 17.8 PC 端错误态/加载态/空态规范 | 错误态已有四层模型（4.4）；Ports 加载中带骨架、失败可重试（8.4）；空态默认「未配置补贴规则」（4.3）；模板下拉 loading 骨架（3.5） | 改默认值 |

> v1.0 中「模板管理是否进一期」的待定项已随 PRD v1.1 关闭（确认进一期）；SDK 侧能力收敛为模板下拉选择（3.5 / 3.8 / 6.5），自动匹配由宿主/后端在 SDK 外部完成。

---

## 12. 里程碑计划

| 里程碑 | 周期 | 交付物 | 验收 |
| --- | --- | --- | --- |
| M1 核心层 | 第 1–2 周 | monorepo 脚手架、core 全量（types/store/validator/calculator/**default-rule**/**http-client**/**api**/**serializer**/messages）+ 单测 + Golden Case 数据集 | 单测全绿；PRD 9.4 八条规则 + 9.7 模板选择流程对应用例通过 |
| M2 PC UI | 第 3–4 周 | ui 组件族 PC 态（**含 TemplateSelect、FixedModeNotice**）、浮层策略、错误态、只读态；vue 包 + host-vue3 demo | 对齐 PC 设计稿走查 |
| M3 三端适配与只读态 | 第 5 周 | elements/vue2/react 包；PC 只读态（详情/审批）；host-vue2 / host-react（**规则引擎模板编辑模式**）demo | 跨宿主契约测试通过；只读页设计走查 |
| M4 e2e 与发布 | 第 6 周 | Playwright e2e、VitePress 文档、CI 发布流水线 | e2e 全绿；`1.0.0-beta.0` 发布 |
| 灰度接入 | 第 7–8 周 | 促销域试点页面 + **规则引擎分摊规则配置页**接入（beta），问题收敛 | PRD 16 节 1/2/7/9 条 SDK 相关项验收 → `1.0.0` |

风险登记（Top3）：① 宿主促销系统为 Vue2 + webpack4 老工程 → M1 即在 host-vue2 示例复现构建链验证；② Shadow DOM 浮层在特定宿主布局（祖先 transform）下定位异常 → 7.1 检测逻辑 + light-dom 降级产物双保险；③ **模板列表依赖规则引擎后端接口就绪** → 3.5 已设计「httpClient 请求失败 / 加载失败」双降级路径（下拉错误态可重试），后端延期不阻塞 SDK 与宿主联调（Mock httpClient 先行）。

---

## 附录 A：核心类型定义（core/types.ts 完整版，对齐后端字段命名与枚举值）

```ts
// ---------- 枚举（对齐后端 UPPER_SNAKE_CASE 风格） ----------
/** 分摊方式（对齐后端 apportionMode） */
export type ApportionMode = 'RATIO' | 'FIXED_AMOUNT' | 'COUPON_FACE_VALUE'
// COUPON_FACE_VALUE 为前端预留，当前后端仅支持 RATIO / FIXED_AMOUNT，待后端补齐

/** 承担方类型（对齐后端 bearerType 字典码） */
export type BearerType = 'PRODUCT_CENTER' | 'HQ' | 'STORE'

/** 商品补贴上限（对齐后端 subsidyCap） */
export type SubsidyCap = 'NO_CAP' | 'ARCHIVE_RETAIL_PRICE' | 'ARCHIVE_DELIVERY_PRICE' | 'COUPON_FACE_VALUE'
// COUPON_FACE_VALUE 为前端预留，仅按券面值模式程序化设置，待后端补齐

/** 承担方式（对齐后端 bearMode） */
export type BearMode = 'FIXED' | 'DYNAMIC'

export type SectionMode = 'edit' | 'readonly'

/** 业务类型（对齐后端 bizType；三方券/生意计划走 PROMOTION_CAMPAIGN） */
export type BizType = 'PROMOTION_CAMPAIGN' | 'COUPON'

/** SDK 使用场景：活动/券规则配置 | 规则引擎模板配置（PRD 9.7） */
export type UsageType = 'activityRule' | 'templateRule'

// ---------- 领域模型（对齐后端 ApportionBearerDTO / ApportionConfigDTO） ----------

/** 部门快照（对齐后端 deptList 元素结构） */
export interface DeptItem {
  deptId: number
  deptCode: string
  deptName: string
}

export interface ApportionBearer {
  id: string                         // 纯前端状态（nanoid），序列化时剥离不传后端
  bearerType: BearerType             // 对齐后端 bearerType
  deptList: DeptItem[]               // 对齐后端 deptList：HQ 必填多选；RATIO 模式下 PRODUCT_CENTER/STORE 为空；FIXED_AMOUNT 模式下非必填
  apportionPer: number | null        // 对齐后端 apportionPer：百分数，两位小数精度（内部存 0.01% 整数）；必须 > 0
  apportionPerSource: 'manual' | 'auto' | null  // 纯前端状态，序列化时剥离
  subsidyCap: SubsidyCap             // 对齐后端 subsidyCap：PRODUCT_CENTER 必填，默认 ARCHIVE_DELIVERY_PRICE
  bearMode: BearMode                 // 对齐后端 bearMode：按顺位自动推导，末位=DYNAMIC，其余=FIXED；不可手动选择
  fixedAmount: number | null         // 对齐后端 fixedAmount：内部以分存储，序列化时 ÷100 转元
  sortIndex: number                  // 纯前端状态：拖拽排序用；序列化时按此排序输出数组，字段本身不传后端
}

export interface ApportionConfig {
  templateId: number | null          // 对齐后端 Long；下拉选中的模板 ID；「自定义」为 null
  templateName: string | null        // 与 templateId 同步写入，仅供展示
  apportionMode: ApportionMode       // 对齐后端 apportionMode
  bearers: ApportionBearer[]
  ruleId?: string
  version?: number
}

/** 提交 payload（序列化后剥离前端状态字段，金额分→元，数组按顺位排序） */
export interface ApportionSubmitPayload extends ApportionConfig {
  submittedAt: string                // ISO8601
}


// ---------- 校验 ----------
export type ErrorCode =
  | 'RATIO_REQUIRED' | 'RATIO_POSITIVE' | 'RATIO_SUM_100'
  | 'DEPT_REQUIRED' | 'CAP_REQUIRED'
  | 'AMOUNT_REQUIRED'                // 移除 DYNAMIC_REQUIRED（顺位自动推导保障）
  | 'BEARER_MIN' | 'TRIAL_PRECHECK'

export interface ValidationError {
  code: ErrorCode
  message: string
  level: 'error' | 'warning'
  target?: {
    bearerId: string
    field: 'apportionPer' | 'deptList' | 'subsidyCap' | 'fixedAmount'  // 对齐后端字段名；移除 'bearMode'
  }
}

export interface ValidateResult {
  valid: boolean
  errors: ValidationError[]
}

// ---------- 试算 ----------
export interface TrialResultItem {
  bearerId: string
  bearerType: BearerType             // 对齐后端
  deptList: DeptItem[]               // 对齐后端
  amount: number                     // 分
  apportionPer?: number              // 承担比例（%），仅 apportionMode=RATIO；展示用
  subsidyCap?: SubsidyCap            // 补贴上限枚举，仅 RATIO 且 PRODUCT_CENTER；展示枚举标签
  bearMode?: BearMode                // 承担方式，仅 FIXED_AMOUNT；展示固定金额/动态补贴
  reason?: 'orderExhausted' | 'dynamicZero'
  sortIndex: number
}

export interface TrialResult {
  items: TrialResultItem[]
  total: number                      // 分
  discountAmount: number             // 分
}

// ---------- 模板（对齐后端 ApportionTemplateVO 返回结构） ----------
export interface ApportionTemplateVO {
  ruleId: number
  ruleName: string
  templateId: number
  templateName: string
  apportionMode: ApportionMode
  bearers: ApportionBearer[]         // 后端返回完整模板内容；SDK 当前仅用 templateId+templateName 作下拉选项
}

/** 接口 2 返回结构（对齐后端 apportion-config/detail 响应） */
export interface ApportionConfigDetailVO {
  configId: number
  bizType: string
  bizId: string
  templateId: number | null
  templateName: string | null
  apportionMode: ApportionMode
  bearers: ApportionBearer[]
}

// ---------- Ports（宿主注入） ----------

/** 环境标识 → 网关 baseURL 映射 */
export type SdkEnv = 'dev' | 'test' | 'pre' | 'prod'

/** 宿主注入的 httpClient 配置 */
export interface HttpClientConfig {
  token: string                      // SDK 用于 Authorization: Bearer {token}；不持久化/不打印/不刷新
  env: SdkEnv                        // SDK 据此选择网关 baseURL
}

/** 三接口路径（SDK 内置默认值，对齐后端实际接口路径，宿主可选覆盖） */
export interface ApiEndpoints {
  templateList: string               // 默认 '/web/promotion/v1/rule-engine/apportion-template/list'
  configuredInfo: string             // 默认 '/web/promotion/v1/apportion-config/detail'
  departments: string                // 默认 '/api/subsidy/departments'（待后端确认）
}

export interface SubsidyHostPorts {
  // —— 网络配置（必填）——
  httpClient: HttpClientConfig       // 宿主注入 token + env
  endpoints?: Partial<ApiEndpoints>  // 可选覆盖三接口路径
  // —— 环境能力（可选）——
  onTrack?(event: { name: string; payload?: Record<string, unknown> }): void
  onError?(error: SdkError): void
  notify?(msg: { type: 'error' | 'info'; text: string }): void
}

export interface SdkError {
  code: 'PORTS_FAILURE' | 'DESERIALIZE_FAILURE' | 'CALC_FAILURE' | 'RENDER_FAILURE'
  message: string
  cause?: unknown
}

// ---------- 组件契约 ----------
export interface SubsidySectionProps {
  value?: ApportionConfig | null     // 降为可选覆盖/兆底；SDK 优先用 httpClient POST 接口 2 拉取
  mode?: SectionMode                 // 默认 'edit'
  usage?: UsageType                  // 默认 'activityRule'
  bizType: BizType                   // SDK 据此映射接口 1 的 applicationDomain 入参
  bizId?: string                     // 接口 2 查询标识（对齐后端 bizId）；编辑态/只读态均需
  activityPurposeId?: number         // 接口 1 入参（对齐后端 activityPurposeId）
  promotionType?: string             // 接口 1 入参（对齐后端 promotionType，PROMOTION 域用）
  ports: SubsidyHostPorts
  theme?: Record<string, string>     // 主题令牌覆写（映射到 CSS 变量）
  trialPlacement?: 'left' | 'right' | 'auto'
  showTrialEntryInReadonly?: boolean // PRD 17.2 预留，默认 false
  disabled?: boolean
}

export interface SubsidySectionExpose {
  validate(): Promise<ValidateResult>
  getPayload(): ApportionSubmitPayload
  setValue(config: ApportionConfig | null): void
  reset(): void
}

// ---------- 移动端默认规则工厂（PRD 14.2/14.3） ----------
/** 移动端创建活动的默认补贴规则：按比例、门店 100%（写死口径，后端落库/宿主兆底复用） */
export function createMobileDefaultRule(): ApportionConfig
```

## 附录 B：纯 JS 宿主兜底接入（无框架 / 老旧页面）

```html
<div id="subsidy-mount"></div>
<script type="module">
  import { mountSubsidySection } from 'https://cdn.internal/@scope/subsidy-elements/1.x/cdn.js'

  const handle = mountSubsidySection(document.getElementById('subsidy-mount'), {
    mode: 'edit', usage: 'activityRule', bizType: 'COUPON',
    bizId: 'Q20261015001',                 // 接口 2 查询标识（对齐后端 bizId）
    activityPurposeId: 10001,               // 接口 1 入参（对齐后端 activityPurposeId）
    ports: {
      httpClient: {                        // 宿主注入 token + env
        token: 'eyJhbGciOi...',
        env: 'dev',                        // → https://dev-gateway.busyming.com
      },
      // endpoints: { templateList: '/custom/path' },  // 可选覆盖
      onError: (err) => console.error(err),
      onTrack: (evt) => analytics.track(evt.name, evt.payload),
    },
    onChange: (config) => console.log(config),
  })
  // 提交前：const { valid } = await handle.validate(); handle.getPayload()
  // 卸载：handle.destroy()
</script>
```

## 附录 C：SDK 侧验收 Checklist（对应 PRD v1.1 第 16 节）

| PRD 16 条目 | SDK 验收方式 |
| --- | --- |
| 1. 优惠券、三方券、促销活动共用配置区块，配置项与校验符合第 9 节（**含模板选择**） | examples 三宿主接入演示 + 校验规则单测矩阵 + 模板下拉用例 |
| 2. 试算结果与第 10 节规则及算例一致 | Golden Case（§10）与业务签字确认的数据集逐分比对 |
| 3. 生效后修改生成新版本 | 后端职责；SDK 侧验证 payload 透传 ruleId/version 正确 |
| 7. 规则引擎支持分摊规则类型与唯一性校验，引擎按活动类型 × 活动目的推荐匹配模板（9.7） | SDK 侧：`usage="templateRule"` 模板编辑界面 + httpClient 调接口 1 下拉选择 e2e（host-react demo）；唯一性校验与**自动匹配/推荐算法**为引擎后端职责 |
| 9. PC 配置区块、详情/审批页只读展示正确；**移动端不展示分摊配置，所建活动默认门店承担 100%** | PC 只读 e2e + 视觉回归；`createMobileDefaultRule` 快照测试与后端落库数据比对（移动端审批页展示不属 SDK 范围） |

> 4/5/6/8 条（T+1 计费、退款调整、核验看板、补贴报表）为后端与报表范畴，不在本 SDK 方案内；core/calculator 的同构复用（§3.6）与 payload 的 `templateId/templateName` 字段（§6.4）为其提供口径与数据保障。
