# 补贴分摊工具 SDK 技术方案

> 版本：v1.0
> 关联文档：《补贴分摊工具1.0-产品需求文档.md》（PRD）、PC / 移动端设计稿 v2
> 范围：前端 SDK（配置工具区块 + 只读展示 + 校验 + 试算），不含计费引擎后端、核验看板后端
> 交付形态：npm 私有仓库多包（Monorepo）

---

## 1. 方案概述

### 1.1 背景

PRD 第 3 节将产品拆为「配置工具」与「营销计费中心」两部分。本方案覆盖**配置工具的前端部分**：以 SDK 形式嵌入优惠券、三方券、促销活动三个业务域的页面（Vue 2 / Vue 3 / React 技术栈并存），提供「配置优惠分摊」区块的编辑态、只读态、试算与校验能力。

选择 SDK 化而非各业务域重复开发的原因：

- PRD 9.1 要求配置工具以**页面内区块**形式嵌入多个宿主页面，且 PC / 移动 H5 **功能完全一致**（14 节），多份实现必然导致校验规则、文案、计算口径漂移；
- PRD 10 节试算口径必须与 T+1 正式计费一致，计算逻辑需要**单点维护、多处复用**（前端试算 + 服务端计费可共用同一份引擎代码）。

### 1.2 设计目标与原则

| 原则 | 说明 |
| --- | --- |
| 逻辑单点维护 | 校验规则、计算口径、文案全部收敛在框架无关的核心层，UI 只负责渲染 |
| 框架无关交付 | 一份 UI 源码，产出 Vue 3 组件、Web Component、React 封装三种产物，覆盖 Vue 2/3/React 宿主 |
| 宿主零污染 | 不注入全局样式/全局变量/全局事件，不发 HTTP 请求，不留单例状态，可挂载可销毁 |
| 端能力一致 | PC 与移动 H5 仅交互容器与布局不同（浮层面板 vs 底部抽屉），功能、校验、文案严格一致 |
| 可验收 | PRD 9.4 的 8 条交互规则、10 节算例全部转化为自动化测试用例 |

### 1.3 PRD 功能 ↔ SDK 模块映射

| PRD 条目 | 功能 | SDK 模块 |
| --- | --- | --- |
| 9.1 | 「配置优惠分摊」内嵌区块、多实例并存 | `SubsidySection` 主组件（实例隔离 Store） |
| 9.2 / 9.3 | 按比例 / 按固定金额两种分摊配置 | `RatioModeEditor` / `FixedModeEditor` + `BearerCard` |
| 9.4-6 | 使用模板（配置只读） | `template` 模式 + `TemplateSelect` |
| 9.4-7 / 9.4-5 | 校验与「必改错误」展示 | `@core` 校验引擎 + `ErrorSummary` / 行内错误 |
| 9.5 | 试算（PC 浮层面板 / 移动底部抽屉） | `TrialPanel` + `@core` 计算引擎 |
| 9.4-1 / 9.4-3 / 9.4-4 | 默认三承担方、自动补齐、删除监控 | `@core` 状态机 Actions |
| 9.4-2 | 试算前置校验 | `@core` 校验引擎（`TRIAL_PRECHECK`） |
| 14 | 详情 / 审批页只读展示 | `SubsidySection mode="readonly"` |
| 14 | PC 横向卡片 / 移动纵向行 + 拖拽排序 | 平台适配层（容器查询 + Pointer 拖拽） |
| 11.2 | 退款提示文案 | 内置文案常量（展示职责，计算在后端） |
| 9.4-8 | 保存草稿 / 提交随宿主表单统一提交 | 命令式 API：`validate()` + `getPayload()`，按钮归属宿主 |

非 SDK 职责（明确排除）：保存/提交/驳回/通过按钮与审批流（宿主）、计费规则存储与版本生成（后端）、T+1 计费与核验看板（后端/大数据）、权限点控制（宿主透传 `mode`/`disabled`）。

---

## 2. 总体架构

### 2.1 分层架构

```
┌────────────────────────────────────────────────────────────┐
│ 宿主应用层（业务域自有代码，SDK 不感知）                        │
│  优惠券(Vue3) │ 三方券(React) │ 促销(Vue2) │ 移动 H5          │
├────────────────────────────────────────────────────────────┤
│ 适配层 Adapters（薄封装，只做 Props/事件/命令式 API 翻译）      │
│  @scope/subsidy-vue   — Vue 3 组件 / 插件                    │
│  @scope/subsidy-vue2  — Vue 2 包装组件（基于 elements）        │
│  @scope/subsidy-react — React 组件（基于 elements）            │
├────────────────────────────────────────────────────────────┤
│ 渲染层 UI（@scope/subsidy-ui，单一 Vue 3 SFC 源码）           │
│  双产物构建：                                                  │
│   ① Vue 3 组件库（供 subsidy-vue）                             │
│   ② Web Components（defineCustomElement，供 vue2/react/任意）  │
│  ├─ 编辑态组件族  ├─ 只读态组件族  ├─ 浮层策略（PC/Mobile）     │
├────────────────────────────────────────────────────────────┤
│ 核心层 Core（@scope/subsidy-core，纯 TypeScript，零框架依赖）   │
│  ├─ 领域类型 & 常量文案                                       │
│  ├─ SectionStore（实例化状态容器 + 交互状态机）                 │
│  ├─ Validator（校验规则引擎）                                  │
│  ├─ Calculator（试算计算引擎，Node 可复用）                     │
│  └─ Ports（宿主数据注入接口：部门/模板/埋点/上报）              │
└────────────────────────────────────────────────────────────┘
```

关键决策：

1. **core 不依赖任何框架**，可在浏览器与 Node 双端运行。试算引擎发布为独立入口，服务端 T+1 计费可直接 `npm install` 复用，从机制上保证 PRD 9.5「计算口径与正式计费一致」。
2. **UI 只写一套**（Vue 3 SFC），通过 Vue 官方 `defineCustomElement` 编译为原生 Web Component。React / Vue 2 宿主不感知 Vue 运行时的存在（运行时已内聚在 elements 产物内部）。
3. **SDK 不内置 HTTP 客户端**。承担方枚举、总部部门（人资组织架构）、分摊模板等数据全部由宿主通过 Ports 接口注入，避免与宿主网关、鉴权、拦截器体系耦合（见 8.1）。

### 2.2 Monorepo 包结构

```
subsidy-sdk/                       # pnpm workspace + changesets
├── packages/
│   ├── core/                      # @scope/subsidy-core
│   │   ├── src/types.ts           #   领域模型（附录 A）
│   │   ├── src/store.ts           #   实例化 Store + 交互 Actions
│   │   ├── src/validator.ts       #   校验规则引擎
│   │   ├── src/calculator.ts      #   试算引擎（isomorphic）
│   │   ├── src/ports.ts           #   宿主注入接口定义
│   │   └── src/messages.ts        #   全部文案常量（单点维护）
│   ├── ui/                        # @scope/subsidy-ui（不直接发布给宿主）
│   │   ├── src/components/        #   Vue 3 SFC 组件族
│   │   ├── src/platform/          #   平台上下文 & 浮层策略
│   │   ├── src/styles/            #   设计令牌 + CSS 变量
│   │   └── src/entries/
│   │       ├── vue.ts             #   产物①：Vue 3 组件入口
│   │       └── elements.ts        #   产物②：customElements 注册入口
│   ├── vue/                       # @scope/subsidy-vue（Vue 3 宿主）
│   ├── vue2/                      # @scope/subsidy-vue2（Vue 2 宿主，封装 elements）
│   └── react/                     # @scope/subsidy-react（React 宿主，封装 elements）
├── examples/
│   ├── host-vue3/  host-vue2/  host-react/  host-h5/   # 四个验证用宿主 Demo
├── docs/                          # VitePress 接入文档
└── e2e/                           # Playwright 跨宿主同一套用例
```

> 包名 scope（如 `@busyming`）以企业私有 registry（Verdaccio/Nexus）实际为准，本文统一写作 `@scope`。

### 2.3 框架兼容策略决策

候选方案对比：

| 维度 | A. Vue3 SFC + `defineCustomElement` 双产物（**推荐**） | B. Headless Core + Vue/React 双 UI 实现 | C. 单框架 UI + 跨框架挂载运行时 |
| --- | --- | --- | --- |
| UI 代码 | 1 套 | 2 套（一致性靠纪律维持） | 1 套 |
| Vue 2 支持 | Custom Element + 薄封装 | 需额外写 Vue 2 版本 | 挂载独立 Vue 3 应用 |
| React 支持 | Custom Element + 薄封装 | 原生组件 | 挂载 Vue 3 应用，bundle 携带 Vue runtime |
| 样式隔离 | Shadow DOM 天然双向隔离 | 需自行实现（前缀/Modules） | 需自行实现 |
| 维护成本 | 低（单一源码） | 高（两套交互同步演进） | 中（双框架运行时共存的隐性成本） |
| 主要风险 | Shadow DOM 内浮层与第三方库限制（可规避，见 7.1） | 校验/交互两份实现漂移 | 宿主已有 Vue 版本冲突、样式污染面大 |

**结论：采用方案 A**。理由：

- 配置区块交互复杂度高（拖拽排序、浮层、抽屉、表单校验），双实现（方案 B）的漂移风险直接影响 PRD 16 节「各端一致」验收；
- 方案 A 的 Shadow DOM 同时解决「SDK 样式不被宿主污染」与「SDK 样式不污染宿主」两个方向（见第 7 章）；
- `defineCustomElement` 为 Vue 3 官方能力，SFC 的 `<style>`、provide/inject、插槽在 custom element 模式下均有明确定义的行为，工程风险可控；
- 同时保留**降级产物**（Light DOM + 类名前缀版，同一源码第二条构建管道），当某宿主环境确与 Shadow DOM 冲突时可无痛切换（见 7.2）。

### 2.4 运行环境基线

| 项 | 基线 | 说明 |
| --- | --- | --- |
| 浏览器 | Chrome ≥ 87、Edge ≥ 88、Safari ≥ 14、iOS Safari ≥ 14、Android WebView/Chrome ≥ 87 | 不支持 IE11（依赖 Custom Elements / Shadow DOM v1 / `ResizeObserver`） |
| 宿主框架 | Vue ≥ 2.7、Vue ≥ 3.2、React ≥ 16.8 | 低于基线的宿主需先升级或使用 IIFE 产物 |
| 构建工具 | 宿主 webpack ≥ 4 / Vite ≥ 3 / Rollup 均可消费 | SDK 产物为 ESM（另附 IIFE 兜底） |
| SSR | SDK 在 SSR 环境仅做空挂载，hydrate 后激活 | elements 注册带 `window` 守卫 |

---

## 3. 核心层设计（@scope/subsidy-core）

### 3.1 领域模型

完整类型定义见附录 A，核心模型摘要：

```ts
/** 分摊方式 */
type ShareMode = 'ratio' | 'fixed'
/** 承担方类型（一期枚举，可通过 Ports 扩展） */
type BearerType = 'productCenter' | 'headquarters' | 'store'
/** 商品补贴上限（仅承担方=产品中心，PRD 9.2） */
type CapType = 'none' | 'retailPrice' | 'deliveryPrice'
/** 承担方式（仅按固定金额，PRD 9.3） */
type ShareType = 'fixedAmount' | 'dynamicSubsidy'

interface BearerConfig {
  id: string                       // 实例内唯一（SDK 生成 nanoid）
  type: BearerType
  departments: string[]            // 具体部门：总部必填多选，其他为空
  ratio: number | null             // 按比例：百分数（80 = 80%），null=未填
  ratioSource: 'manual' | 'auto' | null  // 自动补齐追踪（PRD 9.4-3）
  cap: CapType                     // 补贴上限：产品中心必填，默认 deliveryPrice
  shareType: ShareType             // 按固定金额：承担方式
  fixedAmount: number | null       // 按固定金额：承担金额（元）
  sortIndex: number                // 按固定金额：补贴顺位（拖拽排序）
}

interface SubsidyRuleConfig {
  templateId: string | null        // null=自定义；非 null=使用模板（只读）
  templateName: string | null      // 展示用，如「产品中心30%+门店70%」
  shareMode: ShareMode
  bearers: BearerConfig[]
  ruleId?: string                  // 已保存规则回显时透传（版本逻辑在后端）
  version?: number
}
```

**数值精度约定**（前后端共用，写入 core 常量）：

- 金额内部以**分**（整数）计算，输入/展示层做元 ↔ 分转换，杜绝 `0.1 + 0.2` 浮点误差；
- 比例以 **0.01%** 为最小单位（内部存整数，如 80.00% 存 8000），自动补齐的「100 − 其余之和」在整数域计算后精确到两位小数；
- 舍入统一 `round-half-up`，与财务口径一致；试算结果各承担方金额之和与总额的最后一分钱差异由**顺位最后的承担方**兜底吸收（与大数拆分的常规财务处理一致，若产品另有口径可在 Calculator 配置）。

### 3.2 状态管理：实例化 SectionStore

PRD 9.1 要求「同一页面可同时存在多个配置区块实例」，因此**严禁模块级单例**。core 提供一个约 1KB 的零依赖可观察 Store 工厂：

```ts
interface Store<S> {
  getState(): Readonly<S>
  setState(patch: Partial<S> | ((s: S) => Partial<S>)): void
  subscribe(listener: (s: S, prev: S) => void): () => void
}

/** 每个区块实例调用一次，产出完全隔离的状态容器与 Actions */
function createSectionStore(options: SectionOptions): SectionStore
```

`SectionState` 结构：

```ts
interface SectionState {
  mode: 'edit' | 'readonly'
  platform: 'pc' | 'mobile'
  config: SubsidyRuleConfig
  errors: ValidationError[]        // 当前校验结果（校验引擎输出）
  overlay: 'none' | 'addBearer' | 'trial'   // 当前打开的浮层（单例互斥）
  trial: { inputAmount: number | null; result: TrialResult | null; calculating: boolean }
  ui: { draggingBearerId: string | null }
}
```

Vue 3 侧通过 `shallowRef + subscribe` 绑定为响应式；Web Component 侧同样消费该 store（因为 UI 源码相同）；**React 不直接消费 store**——React 拿到的是 elements 封装后的 DOM 事件与属性，store 完全封装在元素内部，这是方案 A 的隔离红利。

状态变更全部通过命名 Actions 收敛（可单测、可加埋点切面）：

| Action | 对应 PRD 规则 | 行为要点 |
| --- | --- | --- |
| `initDefaultBearers()` | 9.4-1 | 默认生成产品中心/总部/门店三行，ratio=null（显示"请输入"）；产品中心 cap 默认 `deliveryPrice` |
| `setShareMode(mode)` | 9.2/9.3 | 切换分摊方式；切换不清空已填承担方，仅重置模式专属字段并立即重校验 |
| `setBearerRatio(id, v)` | 9.4-3 | 标记 `ratioSource='manual'`；随后执行 `autoFillLastRatio()`；合计 ≠100 时产出 `RATIO_SUM_100` 错误 |
| `autoFillLastRatio()` | 9.4-3/9.4-4 | 见 3.4 节状态机 |
| `addBearer(type)` | 9.4-1 | 从 Picker 添加（已存在类型置灰不可重复，同一类型区块内唯一） |
| `removeBearer(id)` | 9.4-4 | 剩 1 个时阻止并 toast「至少需要有一个承担方」；否则删除并触发 `autoFillLastRatio()` 与重排序 |
| `setShareType(id, st)` | 9.4-5 | 设为 `dynamicSubsidy` 时，其余行的 dynamic 自动降级为 `fixedAmount`（保证最多 1 个） |
| `reorderBearers(from, to)` | 9.3 / 14 | 更新 `sortIndex` 序列（补贴顺位） |
| `applyTemplate(tpl)` | 9.4-6 | 写入模板快照并锁定配置区只读 |
| `submitValidate()` | 9.4-5/9.4-7 | 运行全量校验，供宿主提交前调用 |
| `trial(amount)` | 9.5 | 前置校验 → Calculator 试算 → 写入 `state.trial.result` |

### 3.3 校验引擎

规则即数据，声明式注册，保证 PC/H5/提交/试算四处调用同一份规则：

| 规则码 | 级别 | 文案（messages.ts 单点维护） | 触发时机 | 适用 |
| --- | --- | --- | --- | --- |
| `RATIO_REQUIRED` | error | 请输入 | 字段 blur / 提交 | 按比例-比例为空 |
| `RATIO_SUM_100` | error | 承担比例需为100%，当前{sum}% | 任一 ratio 变化即时 / 提交 | 按比例（sum 保留两位小数） |
| `DEPT_REQUIRED` | error | 请设置 | 字段变化 / 提交 | 承担方=总部且 departments 为空 |
| `CAP_REQUIRED` | error | 请设置 | 字段变化 / 提交 | 承担方=产品中心且 cap 未选 |
| `AMOUNT_REQUIRED` | error | 请输入 | 字段 blur / 提交 | 固定金额为空 |
| `DYNAMIC_REQUIRED` | error | 缺少动态补贴 | shareType 变化即时 / 提交阻止 | 按固定金额且无 dynamic 行 |
| `BEARER_MIN` | error(toast) | 至少需要有一个承担方 | 删除动作时 | 剩 1 行再删 |
| `TRIAL_PRECHECK` | error | 请先完善承担方信息，再进行试算。 | 点击试算 | 任一承担方必填项缺失 |
| `TEMPLATE_LOCKED` | 提示 | 使用模板时分摊方式与承担方配置只读 | UI 态 | 模板模式 |

错误模型：

```ts
interface ValidationError {
  code: ErrorCode
  message: string                  // 已插值的最终文案
  level: 'error' | 'warning'       // error=必改错误（红字+标记）；warning=轻触提示
  target?: { bearerId: string; field: 'ratio' | 'departments' | 'cap' | 'fixedAmount' | 'shareType' }
}
```

- **行内错误**：带 `target` 的错误渲染在对应卡片/行字段下方（红字）；
- **汇总错误**：`ErrorSummary` 展示「必改错误 n」，点击定位到首个错误行（scrollIntoView）；
- **提交语义**：`validate()` 仅在 `errors.filter(e => e.level==='error').length === 0` 时通过；`DYNAMIC_REQUIRED` 在行变更时实时重算，错误消失即解除阻止（PRD 9.4-5）。

### 3.4 关键交互状态机：自动补齐（PRD 9.4-3/9.4-4）

`autoFillLastRatio()` 在每次 ratio 变化、删除承担方后执行：

```
filledManual = bearers 中 ratioSource='manual' 且 ratio≠null 的行
emptyRows    = bearers 中 ratio=null 的行（含 auto 行被清空后）
autoRows     = bearers 中 ratioSource='auto' 的行

IF emptyRows.length === 1 且 filledManual 覆盖其余所有行:
    目标行.ratio       = round2(100 − Σ filledManual.ratio)   // 整数域计算
    目标行.ratioSource = 'auto'
ELSE IF autoRows 存在 且 用户未编辑它:
    若仍满足「唯一未填」条件 → 重算并更新 auto 值
    若不再满足（出现第二个空行）→ 清空 auto 行（ratio=null, ratioSource=null）
用户手动编辑 auto 行 → ratioSource 立即转为 'manual'，此后不再自动补齐
任一变化后 → 若所有行已填且 Σ≠100 → 立即产出 RATIO_SUM_100 错误
```

该状态机用纯函数实现并配套完整单测（等价类：3 行默认、删到 2 行、删到 1 行、auto→manual 转换、合计 99.99/100.01 边界）。

### 3.5 计算引擎（试算，PRD 9.5 / 10）

纯函数、零副作用、浏览器与 Node 同构：

```ts
interface TrialContext {
  /** 命中补贴上限所需的档案价（单位：分），来源见下 */
  retailPrice?: number
  deliveryPrice?: number
}
interface TrialResultItem {
  bearerId: string; type: BearerType; departments: string[]
  amount: number                   // 承担金额（分）
  hitCap: CapType | null           // 命中上限标记（试算面板展示「档案零售价」等）
  sortIndex: number
}
function calculate(input: {
  shareMode: ShareMode
  bearers: BearerConfig[]
  discountAmount: number           // 假设本单优惠金额（分）
  ctx?: TrialContext
}): { items: TrialResultItem[]; total: number }
```

算法（与 PRD 10.1 对齐）：

- **按比例**：`amount_i = discount × ratio_i`，若 cap ≠ none 且 ctx 提供对应档案价，则 `amount_i = min(amount_i, capValue)` 并标记 `hitCap`；
- **按固定金额**：按 `sortIndex` 升序扣减，`amount_i = min(fixedAmount_i, remaining)`，`remaining` 递减至 0 后后续承担方为 0（PRD「按顺序优先扣减，直至为 0」）；dynamic 行 `amount = max(0, discount − Σ fixed)`；
- 输出附带各承担方 `hitCap` 与未补贴原因字段（`reason?: 'cap' | 'orderExhausted' | 'dynamicZero'`），为 PRD 17.1（试算展示字段待确认）预留，确认前按原型稿渲染「承担金额 + 承担比例/补贴上限」。

> 口径备注：PRD 10.1 按比例行描述「若设置了补贴上限，则补贴金额=补贴上限」，与 9.2「上限」语义存在歧义，SDK 按 `min(计算值, 上限)` 实现并列入 §11 开放问题跟踪，若产品确认改为「直接等于上限」仅需调整 Calculator 一处。
>
> 复用：`@scope/subsidy-core/calculator` 单独发布子路径导出，服务端 T+1 计费引擎（Node）依赖同一版本，版本号锁定即锁定口径。

### 3.6 宿主适配端口（Ports）

SDK 所需的一切外部数据与环境能力均通过构造参数注入，SDK 内部**零 fetch / 零 axios**：

```ts
interface SubsidyHostPorts {
  /** 承担方类型枚举：缺省返回内置三项（产品中心/总部/门店） */
  fetchBearerTypes?(): Promise<BearerTypeOption[]>
  /** 具体部门（人资组织架构，承担方=总部时调用，支持多选回显） */
  fetchDepartments(query: { keyword?: string }): Promise<DepartmentOption[]>
  /** 分摊模板列表（PRD 17.2 一期是否开放待定；传 undefined → 隐藏模板选择） */
  fetchTemplates?(): Promise<TemplateOption[]>
  /** 埋点钩子：SDK 内所有关键动作（打开试算/提交校验/增删承担方…） */
  onTrack?(event: { name: string; payload?: Record<string, unknown> }): void
  /** 异常上报：SDK 内部捕获的不可恢复错误 */
  onError?(error: SdkError): void
  /** Toast/通知代理：缺省用 SDK 内置轻量 Toast；宿主可接管统一风格 */
  notify?(msg: { type: 'error' | 'info'; text: string }): void
}
```

依赖注入而非直连接口的收益：宿主网关/鉴权/灰度头不被绕过；SDK 可在任意环境（含无后端的设计走查、单测、Storybook）以 Mock Ports 运行；PRD 15 节权限矩阵落地为「宿主控制 `mode` 与 Ports 返回数据」，SDK 不感知权限。

---

## 4. UI 层设计（@scope/subsidy-ui）

### 4.1 组件拆分

```
SubsidySection                      区块根：提供 PlatformContext / Store / Ports（provide）
├── SectionHeader                   「配置优惠分摊」标题 + 退款提示文案（PRD 11.2 提示）
├── TemplateSelect                  设置模板：自定义 / 模板下拉（Ports.fetchTemplates）
├── ShareModeRadio                  分摊方式：按比例分摊 / 按固定金额分摊
├── BearerList                      承担方列表（PC 横向卡片流 / H5 纵向行，容器查询切换）
│   └── BearerCard × n              单个承担方
│       ├── SortHandle              拖拽手柄（按固定金额模式显示，含「补贴顺位 n」徽标）
│       ├── BearerTypeSelect        承担方下拉（已存在类型禁用重复）
│       ├── DepartmentMultiSelect   具体部门（仅总部，多选，Ports.fetchDepartments）
│       ├── RatioInput              承担比例（%，inputmode=decimal，两位小数）
│       ├── CapSelect               补贴上限（仅产品中心，枚举：不封顶/档案零售价/档案配送价）
│       ├── ShareTypeSelect         承担方式（仅按固定金额：固定金额/动态补贴）
│       ├── FixedAmountInput        承担金额（元，仅 shareType=fixedAmount）
│       ├── FieldError              行内红字错误
│       └── RemoveButton            删除（垃圾桶 icon）
├── BearerAddTrigger                「+ 添加承担方」
├── TrialTrigger                    「试算」（计算器图标）
├── ErrorSummary                    「必改错误 n」汇总条（红字 + 标记）
├── OverlayHost                     浮层挂载点（按平台选择容器，见第 5 章）
│   ├── BearerPickerContent         添加承担方内容（勾选列表，已添加项勾选置灰）
│   └── TrialPanelContent           试算内容（输入优惠金额 → 计算 → 结果列表）
├── Toast                           内置轻量提示（可被 Ports.notify 接管）
└── SubsidySectionReadonly          只读态（独立轻量组件，见 4.3）
```

基础控件（Select/MultiSelect/Radio/Input/Button/Tag/Drawer/Popover/Toast）**自研轻量实现**，不引入 Element/Antd 等宿主级组件库——原因：① 避免与宿主组件库版本冲突及样式互相污染；② Shadow DOM 内第三方库的弹层挂载与样式注入均需改造；③ 区块所需控件集合小，自研体积可控（预算见 9.3）。

### 4.2 编辑态

- **按比例分摊**（PRD 9.2）：BearerCard 展示「承担比例（必填）+ 按承担方类型条件渲染：产品中心 → 补贴上限（默认档案配送价）；总部 → 承担部门（必填多选）」；
- **按固定金额分摊**（PRD 9.3）：BearerCard 展示「承担方式 + 承担金额（shareType=fixedAmount 时必填，dynamicSubsidy 时输入框替换为「承接剩余部分」说明文案）+ SortHandle + 补贴顺位徽标」；排序即扣减顺序，与 PRD「固定金额按顺序依次扣减」一致；
- **使用模板**（PRD 9.4-6）：选择模板后 `ShareModeRadio` 与 `BearerList` 整体转只读展示（复用 4.3 只读渲染），模板下拉显示「使用模板-{模板名}」；
- 三个承担方初始比例均为空、显示占位「请输入」，全部填写后才允许宿主提交（由 `RATIO_REQUIRED` + `validate()` 保证）。

### 4.3 只读态（详情 / 审批页，PRD 14）

`SubsidySectionReadonly`：无输入控件，按原型稿以定义列表/紧凑表格展示「设置模板 / 分摊方式 / 各承担方（承担比例、补贴上限、承担部门）」。

- 复用 core 的 types 与文案，不引入编辑态任何交互代码（按需入口，`readonly` 场景宿主可只引该组件，加载体积更小）；
- 审批操作（转办/驳回/通过）按钮属宿主页面，SDK 只读区块不包含；
- PRD 17.3 待定项「审批页是否展示校验提示/试算入口」：预留 props `showTrialEntryInReadonly`（默认 false），确认后仅改默认值。

### 4.4 错误态

| 层级 | 表现形式 | 来源 |
| --- | --- | --- |
| 行内 | 字段下方红字（如「请输入」「请设置」） | `errors[].target` |
| 区块 | 区块底部红字 + 「必改错误」标记（如「承担比例需为100%，当前85.00%」） | 无 target 的 error |
| 汇总 | 「必改错误 n »」计数条，点击滚动定位首个错误 | errors 聚合 |
| 行为阻止 | 删除阻止 toast、试算前置 toast、提交 `validate()` 返回 false | Actions / Validator |
| 轻提示 | 「轻触提示 n »」（warning 级，预留给产品扩展，如建议性文案） | level=warning |

### 4.5 PRD 9.4 交互规则 → 实现映射总表

| # | PRD 规则 | 实现位置 | 测试 |
| --- | --- | --- | --- |
| 1 | 默认三承担方；Picker 内已勾选置灰 | `initDefaultBearers` + `BearerPickerContent` | core 单测 + e2e |
| 2 | 试算前置校验 | Validator `TRIAL_PRECHECK` | core 单测 |
| 3 | 最后一个承担方自动补齐；手动改后不再补齐 | `autoFillLastRatio` 状态机 | core 单测（等价类全覆盖） |
| 4 | 删除后重算补齐；剩 1 个阻止删除 toast | `removeBearer` | core 单测 + e2e |
| 5 | 固定金额必须含动态补贴，改回即解除 | Validator `DYNAMIC_REQUIRED` 即时重算 | core 单测 + e2e |
| 6 | 使用模板只读 | `applyTemplate` + 只读渲染 | UI 组件测试 |
| 7 | 红字 + 必改错误标记 | ErrorSummary / FieldError | UI 组件测试 + 视觉比对 |
| 8 | 保存/提交归宿主；生效后生成新版本 | 命令式 API（§6.4）；版本由后端处理 | 契约测试 |

---

## 5. 多端适配方案

### 5.1 平台判定

区块是**页面内嵌件**，不能用视口媒体查询推断端（宿主可能在 PC 页面开出窄栏，也可能在移动端 WebView 全宽）。判定优先级：

1. 宿主显式传入 `platform: 'pc' | 'mobile'`（推荐，宿主最清楚自己是什么端）；
2. `platform: 'auto'`（默认）：组件挂载后以 `ResizeObserver` 监听**区块容器自身宽度**，`< 768px` → mobile 交互模式；同时结合 `pointer: coarse` 媒体特征修正（触屏笔记本保持 PC 交互）；
3. 判定结果存入 `PlatformContext`，切换时平滑过渡（仅浮层容器与列表布局变化，状态不重置）。

### 5.2 浮层策略抽象（核心差异点）

PRD 9.1 / 14 的端差异集中在浮层容器，**浮层内容组件两端复用同一份**：

| 功能 | PC（管理后台） | 移动 H5 |
| --- | --- | --- |
| 试算 | 浮层面板 `PcPopoverPanel`：默认锚定「试算」按钮右侧展开，宽 480px；提供 `placement: 'left' \| 'right' \| 'auto'`，防溢出自动翻转 | 底部抽屉 `MobileDrawer`：高 70% 屏，顶部把手，下滑关闭 |
| 添加承担方 | 浮层面板（勾选列表，已添加项勾选置灰） | 底部抽屉（同内容，全宽按钮「确定」） |
| 删除确认 | 气泡确认（或直接删除 + toast，与原型一致） | 直接删除 + toast |
| Toast | 区块顶部居中 | 屏幕中部，safe-area 内 |

实现：

```ts
// platform/OverlayStrategy.ts
interface OverlayStrategy {
  container: Component            // PcPopoverPanel | MobileDrawer
  openAnimation: string
  lockBodyScroll: boolean         // mobile=true（见 5.5 滚动穿透处理）
  anchorToTrigger: boolean        // pc=true
}
```

`OverlayHost` 依据 `PlatformContext` 选择容器，`state.overlay` 决定渲染哪份内容，同一时刻仅一个浮层（单例互斥，打开试算自动关闭 Picker）。浮层打开/关闭动作触发 `Ports.onTrack` 埋点。

### 5.3 响应式布局

- **布局切换基于 CSS 容器查询**（`container-type: inline-size` 设于区块根）：`≥ 768px` 横向卡片流（grid，`minmax(280px, 1fr)` 自动换行），`< 768px` 纵向行式列表；对不支持容器查询的旧浏览器以 ResizeObserver 回退写 `data-layout` 属性选择器（一份样式两种选择器出口，构建时自动生成）；
- 字号/间距使用设计令牌（CSS 变量），PC 与 H5 两套令牌值，随 `data-platform` 切换；
- 卡片内部字段栅格：PC 卡片内字段纵向堆叠；H5 行内字段为「标签左 + 控件右」两栏（与移动端原型一致）。

### 5.4 拖拽排序统一方案

headless 排序逻辑（core 无关平台）+ 平台传感器：

- 统一基于 **Pointer Events** 实现 `useSortable`（不引入 sortablejs 等第三方依赖，避免 Shadow DOM 兼容问题与额外体积）；
- PC：拖拽手柄 pointerdown 即激活；
- Mobile：**长按 300ms** 激活（避免与纵向滚动冲突），激活后卡片浮起（scale 1.02 + 阴影），拖动时 `touch-action: none`；
- 拖动过程仅更新 ui 态（位移 transform），drop 时一次性提交 `reorderBearers(from, to)` → 更新 `sortIndex` 序列与「补贴顺位 n」徽标 → 触发试算结果缓存失效；
- 全程不操作宿主 DOM（拖拽幻影元素渲染在 Shadow Root 内）。

### 5.5 移动端专项细节

| 问题 | 方案 |
| --- | --- |
| 底部抽屉安全区 | `padding-bottom: env(safe-area-inset-bottom)`；抽屉根固定 `max-height: 70vh` 内部滚动 |
| 滚动穿透 | 抽屉打开时对宿主 `body` 加 `overflow: hidden`（记录原值，关闭还原）——这是 SDK 对宿主唯一的临时性样式触碰，写入文档并配套单测保证还原 |
| 数字输入 | 金额/比例输入框 `inputmode="decimal"` 唤起数字键盘；失焦自动格式化两位小数 |
| rem 适配 | SDK 内部**统一 px 体系**（不依赖宿主 `html{font-size}`），`:host` 设定基准字号，组件内部使用 px/em；宿主若为 rem 布局，SDK 区块不受其缩放比例影响，视觉一致性更好 |
| 点击延迟/点透 | 抽屉关闭动画期间屏蔽底层 `pointer-events`（Shadow 内处理） |
| H5 容器 | 移动 H5 宿主通常是独立入口页面（如「新增门店直降」），区块随宿主表单流式布局，无任何定位假设 |

---

## 6. 框架适配层

三端暴露**完全一致的逻辑 API**（同名 props / 事件 / 命令式方法），仅有框架惯用法差异。完整对照表见 6.4。

### 6.1 Vue 3 宿主（`@scope/subsidy-vue`）

原生体验最佳路径，直接消费 UI 产物①（不经 Web Component，无额外运行时）：

```vue
<script setup lang="ts">
import { SubsidySection } from '@scope/subsidy-vue'
import type { SubsidyRuleConfig, SubsidyHostPorts } from '@scope/subsidy-vue'

const config = ref<SubsidyRuleConfig>()
const sectionRef = ref()
const ports: SubsidyHostPorts = {
  fetchDepartments: ({ keyword }) => hrApi.listDepartments({ keyword }),
  onTrack: (e) => tracker.log(e.name, e.payload),
}

async function beforeHostSubmit() {
  const { valid } = await sectionRef.value.validate()
  if (!valid) return false
  return { subsidyRule: sectionRef.value.getPayload() }  // 并入活动表单提交体
}
</script>

<template>
  <SubsidySection
    ref="sectionRef"
    v-model:value="config"
    mode="edit"
    platform="pc"
    biz-type="promotion"
    :ports="ports"
    @error-change="onErrors"
  />
</template>
```

- 支持 `v-model:value`（半受控：SDK 内部持有编辑态，变化时同步出去；宿主不强制回写）；
- 也可 `app.use(SubsidyPlugin)` 全局注册；
- peerDependencies: `vue ^3.2.0`，SDK 不携带 Vue 运行时。

### 6.2 Vue 2 宿主（`@scope/subsidy-vue2`）

Vue 2 页面通过包装组件使用编译产物②（Web Component）。包装组件以 render 函数创建元素，规避 `ignoredElements` 配置，并处理「对象走 property、回调走事件」的桥接：

```js
import SubsidySection from '@scope/subsidy-vue2'

export default {
  components: { SubsidySection },
  methods: {
    async beforeHostSubmit() {
      const { valid } = await this.$refs.subsidy.validate()
      if (!valid) return false
      return { subsidyRule: this.$refs.subsidy.getPayload() }
    },
  },
  template: `
    <SubsidySection ref="subsidy" mode="edit" platform="pc" biz-type="coupon"
      :value="config" :ports="ports" @change="config = $event" />`,
}
```

实现要点（封装在包内，宿主无感）：

- `mounted` 中将对象型 props 以 **property** 赋给元素（`el.value = ...`，绕过 attribute 仅支持字符串的限制），`watch` 同步后续变更；
- SDK 抛出的 `CustomEvent` 桥接为 Vue2 组件 `$emit`；
- 命令式方法直接代理到元素实例；
- 对老旧构建链（webpack 4 + babel）提供转译到 ES2017 的独立产物入口。

### 6.3 React 宿主（`@scope/subsidy-react`）

React 18 及以下对 Custom Element 仅支持字符串 attribute、不支持自定义事件，故提供薄封装（`< 5KB`）：

```tsx
import { useRef } from 'react'
import { SubsidySection, type SubsidySectionHandle } from '@scope/subsidy-react'

export function PromotionForm() {
  const ref = useRef<SubsidySectionHandle>(null)

  const beforeHostSubmit = async () => {
    const { valid } = await ref.current!.validate()
    if (!valid) return false
    return { subsidyRule: ref.current!.getPayload() }
  }

  return (
    <SubsidySection
      ref={ref}
      mode="edit"
      platform="pc"
      bizType="promotion"
      defaultValue={config}
      ports={ports}
      onChange={setConfig}
      onErrorChange={setErrors}
    />
  )
}
```

封装实现要点：

- `useLayoutEffect` 内将对象 props 赋为元素 property、以 `addEventListener` 绑定 `on*` 回调，卸载时完整移除；
- `forwardRef + useImperativeHandle` 暴露 `validate / getPayload / reset / setValue`；
- StrictMode 双挂载安全（注册守卫 + 订阅幂等）；
- React 19 原生支持 Custom Elements，本封装依然保留以保证 API 一致与旧版本兼容；
- peerDependencies: `react >= 16.8`，零额外运行时依赖。

### 6.4 三端 API 对照表

| 能力 | Vue 3 | Vue 2 | React |
| --- | --- | --- | --- |
| 初始值 | `:value` / `v-model:value` | `:value` | `defaultValue`（非受控） |
| 模式 | `mode="edit\|readonly"` | 同左 | 同左 |
| 平台 | `platform="pc\|mobile\|auto"` | 同左 | 同左 |
| 业务域 | `biz-type="coupon\|thirdPartyCoupon\|promotion"` | 同左 | `bizType` |
| 数据注入 | `:ports="ports"` | 同左 | `ports={ports}` |
| 主题 | `:theme="tokens"` | 同左 | `theme={tokens}` |
| 变更事件 | `@change` | `@change` | `onChange` |
| 错误事件 | `@error-change` | `@error-change` | `onErrorChange` |
| 试算完成 | `@trial-complete` | `@trial-complete` | `onTrialComplete` |
| 校验 | `ref.validate(): Promise<{valid, errors}>` | 同左 | `ref.current.validate()` |
| 取提交体 | `ref.getPayload(): RuleSubmitPayload` | 同左 | `ref.current.getPayload()` |
| 重置/赋值 | `ref.reset()` / `ref.setValue(c)` | 同左 | 同左 |
| 销毁 | 组件卸载自动 | 组件 `$destroy` 自动 | 组件卸载自动 |

`RuleSubmitPayload = SubsidyRuleConfig & { submittedAt: string }`：包含 ruleId/version 透传字段，**规则版本生成由后端在活动生效后修改时处理**（PRD 9.4-8 / 16-3），SDK 不实现版本逻辑。

---

## 7. 样式隔离与主题

### 7.1 主方案：Shadow DOM（elements 产物）

`defineCustomElement` 将每个 SFC 的样式编译注入其 Shadow Root，获得双向隔离：宿主全局 CSS（含 `* { margin: 0 }` 这类 reset）不影响 SDK；SDK 样式亦不泄漏至宿主。

配套风险对策（逐条落实为工程约束）：

| 风险 | 对策 |
| --- | --- |
| 浮层 Teleport 到 body 会逃出隔离 | **禁止 Teleport 至 body**：浮层渲染在 Shadow Root 内的 fixed 容器（`OverlayHost`），z-index 在 Shadow 内自治 |
| 宿主祖先链存在 `transform/filter/perspective` 导致 fixed 失效 | 打开浮层时向上遍历检测，命中则将浮层改用绝对定位 + 滚动跟随；并在接入文档中约束宿主避免在 SDK 祖先使用此类样式 |
| 宿主全局字体/图标字体不生效 | SDK 自带基准排版（`:host { font: 14px/1.5 ... }`），图标全部 **inline SVG**（杜绝字体图标跨 Shadow 失效） |
| 宿主想定制主题 | CSS 自定义属性天然穿透 Shadow 边界（见 7.3） |
| Vue 3 宿主直引组件库产物无 Shadow | 产物①采用与降级方案相同的类名前缀隔离（7.2），因为此时宿主是同构 Vue3 工程、样式冲突面可控 |

### 7.2 降级方案：Light DOM + 严格命名空间

同一套源码的第二条样式管道（构建时 postcss 处理，源码零分叉）：

1. 所有类名加 `.ss-` 前缀（CSS Modules hash 前缀固定 `ss`）；
2. 全部选择器以 `:where(.ssdk-root)` 包裹提升一层特异性的同时便于宿主覆写；
3. 根节点 `all: initial` 重置 + 内建局部 reset（仅作用于 `.ssdk-root` 子树）；
4. 不输出任何裸标签选择器、不输出 `@font-face` 到全局、不注入全局变量（变量挂在 `.ssdk-root`）。

适用：产物①（Vue 3 直引版）与确遇 Shadow 兼容问题的宿主。切换方式为换包名导入，API 不变。

### 7.3 主题定制（CSS Variables）

```css
/* 宿主可在任意祖先节点覆写（穿透 Shadow） */
.my-host-theme {
  --ss-color-primary: #ff6a00;      /* 主色（按钮/链接/激活态，默认对齐设计稿橙） */
  --ss-color-error: #f5222d;
  --ss-radius-card: 8px;
  --ss-font-size-base: 14px;
  --ss-z-index-overlay: 1000;       /* 与宿主弹层体系对齐层级 */
}
```

令牌分三层：`color / radius / font / spacing / z-index`，PC 与 H5 各一套默认值，随 `data-platform` 切换。品牌化需求（如企业门户主题色）仅改 `--ss-color-primary` 即可整体生效。

### 7.4 图标与字体

- 图标：构建期将 SVG 内联为组件（`~1KB/个`），无网络请求、无跨 Shadow 字体问题；
- 字体：不引入自定义字体文件，跟随系统字体栈；
- 单位：内部 px/em（见 5.5 rem 说明）。

---

## 8. SDK 与宿主的边界与解耦

### 8.1 职责边界表

| 职责 | SDK | 宿主 | 后端 |
| --- | --- | --- | --- |
| 「配置优惠分摊」区块渲染与交互 | ✔ | | |
| 校验规则、错误文案、试算计算 | ✔（core 单点） | | 复用 core/calculator |
| 承担方枚举 / 部门 / 模板数据 | 定义 Ports 接口 | ✔（实现注入） | ✔（数据源） |
| 保存草稿 / 提交按钮与表单提交流程 | 提供 `validate()`/`getPayload()` | ✔ | ✔ |
| 规则存储、版本生成、历史版本 | 透传 ruleId/version | | ✔ |
| 审批页转办/驳回/通过 | | ✔ | ✔ |
| 权限控制（能否编辑/数据范围） | 响应 `mode`/`disabled` | ✔（权限点判断） | ✔ |
| 埋点上报通道 | 产生事件 | ✔（onTrack 通道） | |
| T+1 计费、退款逆向计费、核验看板 | | | ✔ |

### 8.2 宿主环境零污染约束清单（Code Review 红线）

1. **无全局变量**：不挂 `window.*`（customElements 注册名除外，且带重复注册守卫）；
2. **无全局样式**：见第 7 章；唯一例外是移动抽屉打开时临时锁定 `body` 滚动且保证还原（5.5）；
3. **无全局事件残留**：所有 `window/document` 监听在 `disconnectedCallback` / 卸载钩子中移除；`destroy()` 后不留定时器、不残留 DOM；
4. **无 Polyfill 注入**：SDK 构建目标 ES2017+，需要的 `ResizeObserver` 等能力做特性检测并在不支持时优雅降级（容器查询回退方案见 5.3），不打包 core-js；
5. **无网络请求**：数据一律经 Ports 注入（3.6）；
6. **无跨实例状态**：多实例并存由 `createSectionStore` 工厂保证（3.2），任何模块级可变状态禁止合入；
7. **无原型链修改 / 无依赖冲突**：运行时依赖清零（Vue runtime 仅存在于 elements 产物内部并与宿主隔离）；`package.json` 声明 `"sideEffects": ["*.css"]` 支持 tree-shaking；
8. **错误不扩散**：SDK 内部异常一律捕获 → `Ports.onError` 上报 + 区块降级为只读展示并提示「分摊配置加载异常」，绝不让异常冒泡击穿宿主页面（宿主可另行配置宿主级 ErrorBoundary/错误监听）。

### 8.3 数据流与保存时序（PRD 9.4-8 / 17.5）

```
宿主页面加载
  → hostApi.getActivity() 返回 { subsidyRule? }        （草稿/已生效规则回显，宿主接口）
  → <SubsidySection :value="subsidyRule">              （SDK 反序列化并重建内部状态）

编辑过程
  → SDK 内部状态机 + 即时校验 → @change / @error-change 通知宿主（可用于宿主「未保存」标记）

宿主点击「保存草稿 / 提交创建」（宿主按钮）
  → await ref.validate()
      ✗ → SDK 展示错误（红字+必改错误），宿主中止提交流程
      ✓ → ref.getPayload() → 宿主并入活动表单 body → hostApi.saveActivity()
  → 后端落库规则；活动生效后再修改 → 后端生成新规则版本（SDK 不参与）

详情/审批页
  → <SubsidySection mode="readonly" :value="subsidyRule"> （只读渲染；审批操作宿主实现）
```

草稿态是否落库（PRD 17.5 待定）对 SDK 透明：落库则回显 `value`，不落库则宿主自行缓存 payload。

### 8.4 异常兜底

| 场景 | 行为 |
| --- | --- |
| Ports 数据加载失败（如部门接口超时） | 对应控件进入可重试的错误态（「加载失败，点击重试」），不阻塞其他字段 |
| `value` 反序列化失败（脏数据） | 捕获 → onError → 回退为默认三承担方初始态并提示，保证宿主页面可用 |
| 试算引擎输入异常 | 防御性返回 `items: []` + onError，UI 展示「试算失败，请重试」 |
| SDK 根级渲染异常 | 区块降级为只读占位 + 上报，不影响宿主表单其余部分提交 |

---

## 9. 构建、发布与版本管理

### 9.1 产物规格

| 包 | 入口 | 格式 | 关键配置 |
| --- | --- | --- | --- |
| `@scope/subsidy-core` | `index`、`calculator`（子路径） | ESM + CJS + d.ts | tsup 构建；target ES2017；`sideEffects: false` |
| `@scope/subsidy-vue` | `index` | ESM + d.ts | Vite library mode；`external: ['vue']` |
| `@scope/subsidy-elements` | `index`（ESM）、`cdn`（IIFE） | ESM + IIFE + d.ts | Vue runtime 内联打包；IIFE 供 `<script>` 直引兜底 |
| `@scope/subsidy-vue2` | `index` | ESM（另附 ES2017 转译入口 `legacy`） + d.ts | 依赖 elements |
| `@scope/subsidy-react` | `index` | ESM + d.ts | `external: ['react', 'react-dom']`；依赖 elements |

- 类型统一由 `vue-tsc` / `tsc` 产出 d.ts，`core` 的类型为唯一事实源，各 adapter 包 `export type * from '@scope/subsidy-core'` 再导出，杜绝多端类型漂移；
- 所有包发布前执行 `publint` + `arethetypeswrong` 校验。

### 9.2 发布流程

1. pnpm workspace + **changesets**：每个 PR 附带 changeset 描述变更级别；
2. CI（ lint → 单测 → 构建 → e2e ）通过后，release workflow 自动计算版本、生成 CHANGELOG、发布至企业私有 registry；
3. 通道：`beta` 标签供业务域灰度接入，稳定后 promote 为 `latest`；
4. **语义化版本承诺**：1.x 内 props / 事件 / 命令式 API / Ports 接口向后兼容；破坏性变更（如错误码重命名）必须 major + 迁移指南；
5. **core/calculator 与后端计费引擎共版本**：服务端以精确版本号依赖，升级需双方对齐回归 PRD 10.4 算例。

### 9.3 体积与性能预算（gzip）

| 产物 | 预算 | 说明 |
| --- | --- | --- |
| core | ≤ 15 KB | 纯逻辑，可独立用于 Node |
| vue（不含 vue runtime） | ≤ 45 KB | Vue 3 宿主增量成本 |
| elements（含 Vue runtime） | ≤ 85 KB | Vue2/React 宿主一次性成本，建议宿主路由级懒加载 |
| vue2 / react adapter | ≤ 5 KB | 薄封装 |

性能要求：区块首渲染 ≤ 100ms（PC Chrome 中位）；浮层打开 ≤ 16ms 首帧；`validate()` 为同步规则的全量遍历（承担方数量级为个位数），耗时忽略；编辑态仅在必要时渲染浮层内容（v-if），多实例页面内存随实例数线性增长且无共享泄漏。

---

## 10. 测试方案

| 层 | 工具 | 覆盖内容 |
| --- | --- | --- |
| 单元测试 | Vitest | ① 校验引擎：§3.3 全部规则码 × 触发时机矩阵；② 自动补齐状态机等价类（§3.4）；③ 计算引擎：按比例/上限命中/固定金额顺序扣减/动态兜底/精度边界（99.99、100.01、分单位进位）；④ Store 多实例隔离 |
| Golden Case | Vitest 数据集 | **PRD 10.4 四笔算例订单**（S103E…/S104F…/S101L…/S109A…）转为 JSON 数据集，试算结果与业务确认值逐分比对；后端计费引擎共用同一数据集保证口径 |
| 组件测试 | @vue/test-utils + happy-dom | 模板只读态、错误汇总定位、Picker 置灰逻辑、只读态渲染 |
| 跨宿主契约测试 | Vitest | 三端 adapter 对同一组操作产出一致的事件序列与 payload（6.4 对照表逐行断言） |
| E2E | Playwright | **同一套交互脚本**跑在 examples 的 vue2/vue3/react/h5 四个宿主上：默认三承担方 → 填比例（验证自动补齐）→ 试算 → 切固定金额（验证动态补贴校验）→ 拖拽排序 → 删除阻止 toast；移动端用例在 Mobile Safari 仿真下跑抽屉交互 |
| 视觉回归 | Playwright 截图比对 | 对齐 PC / 移动设计稿关键态（默认态、错误态、试算面板、只读态） |
| 性能 | Lighthouse CI（examples/h5） | FCP/TTI 基线监控，elements 产物加载体积门禁 |

---

## 11. PRD 开放问题（第 17 节）的 SDK 默认策略

| PRD 待定项 | SDK 默认实现 | 确认后的变更成本 |
| --- | --- | --- |
| 17.1 试算口径与展示字段 | `TrialResultItem` 已含 `hitCap/reason` 预留字段；UI 按原型展示「承担金额+比例/上限」 | 仅改展示，不动结构 |
| 17.2 分摊模板管理是否进一期 | `fetchTemplates` 为可选 Port；宿主不传 → 隐藏模板下拉；传 → 启用模板只读流程 | 零 SDK 改动 |
| 17.3 审批页是否展示校验/试算入口 | `showTrialEntryInReadonly`（默认 false）、只读态不渲染错误 | 改默认值 |
| 17.4 生效后修改的二次确认与版本历史 | 宿主职责；SDK payload 透传 `ruleId/version` | 零 SDK 改动 |
| 17.5 草稿是否落库 | 对 SDK 透明（8.3） | 零 SDK 改动 |
| 17.6 权限矩阵 | 宿主以 `mode/disabled/Ports 数据` 表达 | 零 SDK 改动 |
| 17.7 PC 浮层锚定/尺寸、空态/加载态规范 | 试算面板默认 480px 右侧展开，`placement` 可配；Ports 加载中带骨架、失败可重试（8.4） | 改默认值 |

---

## 12. 里程碑计划

| 里程碑 | 周期 | 交付物 | 验收 |
| --- | --- | --- | --- |
| M1 核心层 | 第 1–2 周 | monorepo 脚手架、core 全量（types/store/validator/calculator/messages）+ 单测 + Golden Case 数据集 | 单测全绿；PRD 9.4 八条规则对应用例通过 |
| M2 PC UI | 第 3–4 周 | ui 组件族 PC 态、浮层策略、错误态、只读态；vue 包 + host-vue3 demo | 对齐 PC 设计稿走查 |
| M3 移动端 | 第 5 周（含并行缓冲） | H5 布局、底部抽屉、长按拖拽、容器查询回退；host-h5 demo | 对齐移动端设计稿走查 + Lighthouse 达标 |
| M4 三端适配与发布 | 第 6 周 | elements/vue2/react 包、四个 examples、Playwright e2e、VitePress 文档、CI 发布流水线 | 跨宿主契约测试 + e2e 全绿；`1.0.0-beta.0` 发布 |
| 灰度接入 | 第 7–8 周 | 促销域试点页面接入（beta），问题收敛 | PRD 16 节 1/2/7 条 SDK 相关项验收 → `1.0.0` |

风险登记（Top3）：① 宿主促销系统为 Vue2 + webpack4 老工程 → M1 即在 host-vue2 示例复现构建链验证；② Shadow DOM 浮层在特定宿主布局（祖先 transform）下定位异常 → 7.1 检测逻辑 + light-dom 降级产物双保险；③ PRD 17.x 待定项结论晚于开发 → §11 全部以可配置默认值实现，结论落地零返工。

---

## 附录 A：核心类型定义（core/types.ts 完整版）

```ts
// ---------- 枚举 ----------
export type ShareMode = 'ratio' | 'fixed'
export type BearerType = 'productCenter' | 'headquarters' | 'store'
export type CapType = 'none' | 'retailPrice' | 'deliveryPrice'
export type ShareType = 'fixedAmount' | 'dynamicSubsidy'
export type Platform = 'pc' | 'mobile'
export type PlatformInput = Platform | 'auto'
export type SectionMode = 'edit' | 'readonly'
export type BizType = 'coupon' | 'thirdPartyCoupon' | 'promotion'

// ---------- 领域模型 ----------
export interface BearerConfig {
  id: string
  type: BearerType
  departments: string[]
  ratio: number | null                 // 百分数，两位小数精度（内部存 0.01% 整数）
  ratioSource: 'manual' | 'auto' | null
  cap: CapType
  shareType: ShareType
  fixedAmount: number | null           // 元（内部存分）
  sortIndex: number
}

export interface SubsidyRuleConfig {
  templateId: string | null
  templateName: string | null
  shareMode: ShareMode
  bearers: BearerConfig[]
  ruleId?: string
  version?: number
}

export interface RuleSubmitPayload extends SubsidyRuleConfig {
  submittedAt: string                  // ISO8601
}

// ---------- 校验 ----------
export type ErrorCode =
  | 'RATIO_REQUIRED' | 'RATIO_SUM_100'
  | 'DEPT_REQUIRED' | 'CAP_REQUIRED'
  | 'AMOUNT_REQUIRED' | 'DYNAMIC_REQUIRED'
  | 'BEARER_MIN' | 'TRIAL_PRECHECK' | 'TEMPLATE_LOCKED'

export interface ValidationError {
  code: ErrorCode
  message: string
  level: 'error' | 'warning'
  target?: {
    bearerId: string
    field: 'ratio' | 'departments' | 'cap' | 'fixedAmount' | 'shareType'
  }
}

export interface ValidateResult {
  valid: boolean
  errors: ValidationError[]
}

// ---------- 试算 ----------
export interface TrialContext {
  retailPrice?: number                 // 分
  deliveryPrice?: number               // 分
}

export interface TrialResultItem {
  bearerId: string
  type: BearerType
  departments: string[]
  amount: number                       // 分
  hitCap: CapType | null
  reason?: 'cap' | 'orderExhausted' | 'dynamicZero'
  sortIndex: number
}

export interface TrialResult {
  items: TrialResultItem[]
  total: number                        // 分
  discountAmount: number               // 分
}

// ---------- Ports（宿主注入） ----------
export interface BearerTypeOption { type: BearerType; label: string }
export interface DepartmentOption { id: string; name: string }
export interface TemplateOption {
  templateId: string
  name: string                         // 如「产品中心30%+门店70%」
  snapshot: Omit<SubsidyRuleConfig, 'templateId' | 'templateName' | 'ruleId' | 'version'>
}

export interface SubsidyHostPorts {
  fetchBearerTypes?(): Promise<BearerTypeOption[]>
  fetchDepartments(query: { keyword?: string }): Promise<DepartmentOption[]>
  fetchTemplates?(): Promise<TemplateOption[]>
  onTrack?(event: { name: string; payload?: Record<string, unknown> }): void
  onError?(error: SdkError): void
  notify?(msg: { type: 'error' | 'info'; text: string }): void
}

export interface SdkError {
  code: 'PORTS_FAILURE' | 'DESERIALIZE_FAILURE' | 'CALC_FAILURE' | 'RENDER_FAILURE'
  message: string
  cause?: unknown
}

// ---------- 组件契约 ----------
export interface SubsidySectionProps {
  value?: SubsidyRuleConfig | null
  mode?: SectionMode                   // 默认 'edit'
  platform?: PlatformInput             // 默认 'auto'
  bizType: BizType
  ports: SubsidyHostPorts
  theme?: Record<string, string>       // 主题令牌覆写（映射到 CSS 变量）
  trialPlacement?: 'left' | 'right' | 'auto'
  showTrialEntryInReadonly?: boolean   // PRD 17.3 预留，默认 false
  disabled?: boolean
}

export interface SubsidySectionExpose {
  validate(): Promise<ValidateResult>
  getPayload(): RuleSubmitPayload
  setValue(config: SubsidyRuleConfig | null): void
  reset(): void
}
```

## 附录 B：纯 JS 宿主兜底接入（无框架 / 老旧页面）

```html
<div id="subsidy-mount"></div>
<script type="module">
  import { mountSubsidySection } from 'https://cdn.internal/@scope/subsidy-elements/1.x/cdn.js'

  const handle = mountSubsidySection(document.getElementById('subsidy-mount'), {
    mode: 'edit', platform: 'auto', bizType: 'coupon',
    ports: { fetchDepartments: (q) => fetchDepartmentsFromHost(q) },
    onChange: (config) => console.log(config),
  })
  // 提交前：const { valid } = await handle.validate(); handle.getPayload()
  // 卸载：handle.destroy()
</script>
```

## 附录 C：SDK 侧验收 Checklist（对应 PRD 16）

| PRD 16 条目 | SDK 验收方式 |
| --- | --- |
| 1. 三业务域共用配置区块、配置项与校验符合第 9 节 | 四个 examples 宿主接入演示 + 校验规则单测矩阵 |
| 2. 试算结果与第 10 节规则及算例一致 | Golden Case（附录/§10）与业务签字确认的数据集逐分比对 |
| 3. 生效后修改生成新版本 | 后端职责；SDK 侧验证 payload 透传 ruleId/version 正确 |
| 7. PC / 移动 H5、详情 / 审批页只读展示正确 | Playwright 双端 e2e + 视觉回归 + 设计走查单 |

> 4/5/6 条（T+1 计费、退款调整、核验看板）为后端与报表范畴，不在本 SDK 方案内，但 core/calculator 的同构复用（§3.5）为其提供口径保障。
